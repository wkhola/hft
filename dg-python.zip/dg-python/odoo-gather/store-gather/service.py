# coding:utf8
import sys

import common
import logging
from logger import Logger
__author__ = 'Caoyu'

_logger = Logger("service.py")
conn_pg = common.conn_pg


def query_pg_store_info():
    """
    查询PG中的店铺信息
    :return:
    """
    # 新增 corporator (项目店名 如 hft) ，create_date (开店日期)  两个字段
    last_store_id = common.get_last_store_id()
    sql = "SELECT SS.id AS store_id, SS.name, SS.shop_short_name, SS.status, SS.shop_no, SS.signed, SS.own_user_id, " \
          "SS.corporator, to_char(SS.create_date, 'yyyy-mm-dd hh24:mi:ss') AS create_date, SU.name AS own_user_name, " \
          "SU.tel AS own_user_tel, SS.address, RCS.name AS province, RCSC.name AS city, RCSD.name AS district, " \
          "SS.shop_categ as categ, SS.gps_address as gps_address, SS.gps_name as gps_name, " \
          "SS.gps_latitude as gps_latitude, SS.gps_longitude as gps_longitude FROM " \
          "shop_store AS SS LEFT JOIN shop_user AS SU ON SS.own_user_id = SU.id LEFT JOIN res_country_state AS RCS " \
          "ON SS.state_id = RCS.ID LEFT JOIN res_country_state_city AS RCSC ON SS.city = RCSC.id LEFT JOIN " \
          "res_country_state_city_district AS RCSD ON SS.district = RCSD.id WHERE SS.id  > " + str(last_store_id)

    """
    上面SQL可能不太容易观看, 具体看这里
    SELECT SS.id AS store_id, SS.name, SS.shop_short_name, SS.status, SS.shop_no, SS.signed, SS.own_user_id, SS.corporator, to_char(SS.create_date, 'yyyy-mm-dd hh24:mi:ss') AS create_date, SU.name AS own_user_name, SU.tel AS own_user_tel, SS.address, RCS.name AS province, RCSC.name AS city, RCSD.name AS district FROM shop_store AS SS LEFT JOIN shop_user AS SU ON SS.own_user_id = SU.id LEFT JOIN res_country_state AS RCS ON SS.state_id = RCS.ID LEFT JOIN res_country_state_city AS RCSC ON SS.city = RCSC.id LEFT JOIN res_country_state_city_district AS RCSD ON SS.district = RCSD.id WHERE SS.id > 0
    """
    # Run sql script and get result
    cursor = conn_pg.cursor()
    cursor.execute(sql)
    result = cursor.fetchall()

    all_store_info_list = []

    for single_store_info in result:
        single_store_info_dict = dict()
        single_store_info_dict['id'] = single_store_info[0]
        single_store_info_dict['name'] = single_store_info[1]
        single_store_info_dict['short_name'] = single_store_info[2]
        single_store_info_dict['status'] = single_store_info[3]
        single_store_info_dict['shop_no'] = single_store_info[4]
        single_store_info_dict['signed'] = single_store_info[5]
        single_store_info_dict['own_user_id'] = single_store_info[6]
        single_store_info_dict['corporator'] = single_store_info[7]
        single_store_info_dict['create_date'] = single_store_info[8]
        single_store_info_dict['own_user_name'] = single_store_info[9]
        single_store_info_dict['own_user_tel'] = single_store_info[10]
        single_store_info_dict['address'] = single_store_info[11]
        single_store_info_dict['province'] = single_store_info[12]
        single_store_info_dict['city'] = single_store_info[13]
        single_store_info_dict['district'] = single_store_info[14]
        single_store_info_dict['categ'] = single_store_info[15]
        single_store_info_dict['gps_address'] = single_store_info[16]
        single_store_info_dict['gps_name'] = single_store_info[17]
        single_store_info_dict['gps_latitude'] = single_store_info[18]
        single_store_info_dict['gps_longitude'] = single_store_info[19]
        all_store_info_list.append(single_store_info_dict)

    _logger.info("查询odoo店铺信息, 成功, 从店铺: " + str(last_store_id) + " 开始, 查询店铺数量: " + str(len(all_store_info_list)))
    return all_store_info_list


def insert_store_info_to_dw(all_store_info_list):
    """
    将查询到的店铺信息写入数据仓库
    :param all_store_info_list:
    :return: None
    """
    conn_mysql = common.conn_mysql
    cursor = conn_mysql.cursor()
    max_store_id = 0
    try:
        for single_store_info_dict in all_store_info_list:
            store_id = single_store_info_dict['id']
            name = single_store_info_dict['name']
            short_name = single_store_info_dict['short_name']
            status = single_store_info_dict['status']
            shop_no = single_store_info_dict['shop_no']
            signed = single_store_info_dict['signed']
            own_user_id = single_store_info_dict['own_user_id']
            corporator = single_store_info_dict['corporator']
            create_date = single_store_info_dict['create_date']
            own_user_name = single_store_info_dict['own_user_name']
            own_user_tel = single_store_info_dict['own_user_tel']
            address = single_store_info_dict['address']
            province = single_store_info_dict['province']
            city = single_store_info_dict['city']
            district = single_store_info_dict['district']
            categ = single_store_info_dict['categ']
            gps_address = single_store_info_dict['gps_address']
            gps_name = single_store_info_dict['gps_name']
            gps_latitude = single_store_info_dict['gps_latitude']
            gps_longitude = single_store_info_dict['gps_longitude']

            if store_id > max_store_id:
                max_store_id = store_id

            # own_user_tel 从odoo中查询出来是字符串, 但是数据仓库要求是数字, 所以 用 %s 表示, 而不是 '%s' 来组成sql语句
            sql = "REPLACE INTO store(id, name, short_name, status, shop_no, signed, own_user_id, " \
                  "own_user_name, own_user_tel, corporator, create_date, address, province, city, district, categ, " \
                  "gps_address, gps_name, gps_latitude, gps_longitude) " \
                  "VALUES(%d, '%s', '%s', '%s', '%s', %d, %d, '%s', %s, '%s', '%s', '%s', '%s', '%s', '%s', '%s'," \
                  " '%s', '%s', '%s', '%s')" % \
                  (store_id, name, short_name, status, shop_no, 1 if signed else 0, own_user_id, own_user_name,
                   own_user_tel, corporator, create_date, address, province, city, district, categ,
                   gps_address, gps_name, gps_latitude, gps_longitude)
            cursor.execute(sql)
            conn_mysql.commit()
            _logger.info("插入一条店铺信息到数据仓库, id: " + str(store_id) + ", name: " + name)
    except Exception, e:
        _logger.error("准备数据并插入数据到数据仓库出错.")
        _logger.exception(e)
        return False

    # 全部插入完成, 才写入文件缓存, 记录这次查询并插入的最大store_id
    common.write_last_store_id(max_store_id)
    return True
    # print type(id), 'id', id
    # print type(name), 'name', name
    # print type(short_name), 'short_name', short_name
    # print type(status), 'status', status
    # print type(shop_no), 'shop_no', shop_no
    # print type(signed), 'signed', signed
    # print type(own_user_id), 'ownuserid', own_user_id
    # print type(own_user_name), 'ownusername', own_user_name
    # print type(own_user_tel), 'ownusertel', own_user_tel
    # print type(address), 'add', address
    # print type(province), 'prov', province
    # print type(city), 'city', city
    # print type(district), 'dist', district
