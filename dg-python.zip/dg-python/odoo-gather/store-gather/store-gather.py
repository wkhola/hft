#! /usr/bin/python
# coding:utf8

import service
from logger import Logger

__author__ = 'CaoYu'
_logger = Logger('store-gather.py')

if __name__ == '__main__':
    all_store_info_list = service.query_pg_store_info()
    if all_store_info_list:
        _logger.info("查询出一些店铺信息, 开始执行插入操作")
        service.insert_store_info_to_dw(all_store_info_list)
    else:
        _logger.info("本次查询没有查询出店铺信息, 不进行插入操作")

    _logger.info("本次执行结束.")
    _logger.info("----------------------------------------------------------")
