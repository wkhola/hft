# coding:utf8

import MySQLdb
import ConfigParser
import string
import psycopg2
import os
from logger import Logger


"""
公共组件文件, 包含所有公共方法供使用
"""
__author__ = 'CaoYu'


logger = Logger('common.py')

conf = ConfigParser.ConfigParser()
conf.read("/home/hft/odoo-gather-python/store-gather/config.conf")
last_store_id_file_path = conf.get('common', 'last_store_id_file_path')


# Get connection for mysql
conn_mysql = MySQLdb.connect(
    host=conf.get('mysql', 'db_host'),
    port=string.atoi(conf.get('mysql', 'db_port')),
    user=conf.get('mysql', 'db_user'),
    passwd=conf.get('mysql', 'db_password'),
    db=conf.get('mysql', 'db_db'),
    charset='utf8'
)

# Get connection for postgresql
conn_pg = psycopg2.connect(
    database=conf.get('postgresql', 'db_db'),
    user=conf.get('postgresql', 'db_user'),
    password=conf.get('postgresql', 'db_password'),
    host=conf.get('postgresql', 'db_host'),
    port=string.atoi(conf.get('postgresql', 'db_port'))
)


def close_all_connection():
    """
    Close all db connection
    :return: None
    """
    conn_mysql.close()
    conn_pg.close()


def init():
    """
    初始化
    :return:
    """
    if not os.path.exists(last_store_id_file_path):
        open(last_store_id_file_path, 'a')
        logger.info("缓存上次查询的缓存文件: " + last_store_id_file_path + " 不存在, 创建...")


def get_last_store_id():
    """
    获得上次查询到的store_id
    :return: 0 第一次, 非第一次返回store_id
    """
    last_store_id_file_r = open(last_store_id_file_path, 'r')
    last_store_id = last_store_id_file_r.readline()
    if not last_store_id:
        logger.info("查询上次查询的store_id方法: 这是第一次查询, 返回店铺ID为0")
        return 0
    else:
        logger.info("查询上次查询的store_id方法: 从文件中取得店铺ID为: " + str(last_store_id))
        return last_store_id


def write_last_store_id(store_id):
    """
    写上次查询到的store_id到文件中, 每次都清空文件.
    :param store_id:
    :return: None
    """
    logger.info("写store_id到缓存文件中, 当前store_id为: " + str(get_last_store_id()) + ", 当前写入: " + str(store_id))
    store_id = str(store_id)
    last_store_id_file_w = open(last_store_id_file_path, 'w')
    last_store_id_file_w.write(store_id)


# Import this python file must be run init function.
init()
