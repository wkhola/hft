# coding:utf8

import common
import logging
from logger import Logger
__author__ = 'Caoyu'

_logger = Logger("service.py")
conn_pg = common.conn_pg


def query_user_info():
    """
    查询店主信息, 从odoo的pg数据库
    :return: user_info_list
    """
    last_user_id = str(common.get_last_user_id())    # 获取上次查询得到的最大user_id, 如果第一次查询会返回0
    sql = "SELECT id, name, tel, address, uuid, create_date FROM shop_user WHERE id > " + last_user_id
    cursor = conn_pg.cursor()
    cursor.execute(sql)
    result = cursor.fetchall()

    user_infos = []

    for user_info in result:
        single_user_info_dict = dict()
        single_user_info_dict['id'] = user_info[0]
        single_user_info_dict['name'] = user_info[1]
        single_user_info_dict['tel'] = user_info[2]
        single_user_info_dict['address'] = user_info[3]
        single_user_info_dict['uuid'] = user_info[4]
        single_user_info_dict['create_date'] = user_info[5]

        user_infos.append(single_user_info_dict)
    _logger.info("查询odoo店主信息成功, 从店主ID: " + last_user_id + '开始, 查询到: ' + str(len(user_infos)) + '个店主信息.')
    return user_infos


def query_staff_info():
    """
    查询员工信息, 从odoo的pg数据库
    :return: staff_info_list
    """
    last_staff_id = str(common.get_last_staff_id())     # 获取上次查询得到的最大staff_id, 如果第一次查询会返回0
    sql = "SELECT SUS.id, SUS.name, SUS.tel, SUS.uuid, SS.own_user_id, SU.name AS own_user_name, " \
          "SU.tel AS own_user_tel, own_store_id, SS.name AS own_store_name, SS.shop_short_name " \
          "AS own_store_short_name, SUS.create_date FROM shop_user_staff AS SUS LEFT JOIN shop_store AS SS " \
          "ON SUS.own_store_id = SS.id LEFT JOIN shop_user AS SU on SS.own_user_id = SU.id " \
          "WHERE SUS.id > " + last_staff_id
    cursor = conn_pg.cursor()
    cursor.execute(sql)
    result = cursor.fetchall()

    staff_infos = []

    for staff_info in result:
        single_staff_info_dict = dict()
        single_staff_info_dict['id'] = staff_info[0]
        single_staff_info_dict['name'] = staff_info[1]
        single_staff_info_dict['tel'] = staff_info[2]
        single_staff_info_dict['uuid'] = staff_info[3]
        single_staff_info_dict['own_user_id'] = staff_info[4]
        single_staff_info_dict['own_user_name'] = staff_info[5]
        single_staff_info_dict['own_user_tel'] = staff_info[6]
        single_staff_info_dict['own_store_id'] = staff_info[7]
        single_staff_info_dict['own_store_name'] = staff_info[8]
        single_staff_info_dict['own_store_short_name'] = staff_info[9]
        single_staff_info_dict['create_date'] = staff_info[10]

        staff_infos.append(single_staff_info_dict)

    _logger.info("查询odoo店员信息成功, 从店员ID: " + last_staff_id + '开始, 查询到: ' + str(len(staff_infos)) + '个店员信息.')
    return staff_infos


def insert_user_info(user_infos):
    """
    插入店主信息至data warehouse
    :return: True or False
    """
    conn_mysql = common.conn_mysql
    cursor = conn_mysql.cursor()
    max_user_id = 0

    try:
        for user_info in user_infos:
            user_id = user_info['id']
            name = user_info['name']
            tel = user_info['tel']
            address = user_info['address']
            uuid = user_info['uuid']
            create_date = user_info['create_date']

            if user_id > max_user_id:
                max_user_id = user_id
            # tel字段odoo查出来是字符串, 但是插入的数据仓库是数字. 所以用%s 但是不带''
            sql = "REPLACE INTO `user`(id, name, tel, address, uuid, create_date) " \
                  "VALUES(%d, '%s', %s, '%s', '%s', '%s')" % \
                  (user_id, name, tel, address, uuid, create_date)
            cursor.execute(sql)
            conn_mysql.commit()
            _logger.info("插入一条数据至user表成功, user_id: " + str(user_id) + ", name: " + name)
    except Exception, e:
        _logger.error("准备数据并插入数据到数据仓库出错(user).")
        logging.exception(e)
        return False

    common.write_last_user_id(max_user_id)
    return True


def insert_staff_info(staff_infos):
    """
    插入店员信息到数据仓库
    :return: True or False
    """
    conn_mysql = common.conn_mysql
    cursor = conn_mysql.cursor()

    max_staff_id = 0

    try:
        for staff_info in staff_infos:
            staff_id = staff_info['id']
            name = staff_info['name']
            tel = staff_info['tel']
            uuid = staff_info['uuid']
            own_user_id = staff_info['own_user_id']
            own_user_name = staff_info['own_user_name']
            own_user_tel = staff_info['own_user_tel']
            own_store_id = staff_info['own_store_id']
            own_store_name = staff_info['own_store_name']
            own_store_short_name = staff_info['own_store_short_name']
            create_date = staff_info['create_date']

            if staff_id > max_staff_id:
                max_staff_id = staff_id

            sql = "REPLACE INTO `staff`(id, name, tel, uuid, own_user_id, own_user_name, " \
                  "own_user_tel, own_store_id, own_store_name, own_store_short_name, create_date) VALUES(" \
                  "%d, '%s', %s, '%s', %d, '%s', %s, %d, '%s', '%s', '%s')" % \
                  (staff_id, name, tel, uuid, own_user_id, own_user_name, own_user_tel,
                   own_store_id, own_store_name, own_store_short_name, create_date)
            cursor.execute(sql)
            conn_mysql.commit()
            _logger.info("插入一条员工信息成功, id: " + str(staff_id) + ", name: " + name)
    except Exception, e:
        _logger.error("准备数据并插入数据到数据仓库出错(staff).")
        _logger.exception(e)
        return False

    common.write_last_staff_id(max_staff_id)
    return True
