# coding:utf8

import MySQLdb
import ConfigParser
import string
import psycopg2
import os
from logger import Logger


"""
公共组件文件, 包含所有公共方法供使用
"""
__author__ = 'CaoYu'


logger = Logger('common.py')

conf = ConfigParser.ConfigParser()
conf.read("/home/hft/odoo-gather-python/user-gather/config.conf")
last_user_id_file_path = conf.get('common', 'last_user_id_path')
last_staff_id_file_path = conf.get('common', 'last_staff_id_path')


# Get connection for mysql
conn_mysql = MySQLdb.connect(
    host=conf.get('mysql', 'db_host'),
    port=string.atoi(conf.get('mysql', 'db_port')),
    user=conf.get('mysql', 'db_user'),
    passwd=conf.get('mysql', 'db_password'),
    db=conf.get('mysql', 'db_db'),
    charset='utf8'
)

# Get connection for postgresql
conn_pg = psycopg2.connect(
    database=conf.get('postgresql', 'db_db'),
    user=conf.get('postgresql', 'db_user'),
    password=conf.get('postgresql', 'db_password'),
    host=conf.get('postgresql', 'db_host'),
    port=string.atoi(conf.get('postgresql', 'db_port'))
)


def close_all_connection():
    """
    Close all db connection
    :return: None
    """
    conn_mysql.close()
    conn_pg.close()


def init():
    """
    初始化
    :return:
    """
    if not os.path.exists(last_user_id_file_path):
        open(last_user_id_file_path, 'a')
        logger.info("缓存上次查询的缓存文件: " + last_user_id_file_path + " 不存在, 创建...")

    if not os.path.exists(last_staff_id_file_path):
        open(last_staff_id_file_path, 'a')
        logger.info("缓存上次查询的缓存文件: " + last_staff_id_file_path + " 不存在, 创建...")


def get_last_user_id():
    """
    获得上次查询到的userID
    :return: 0 第一次, 非第一次返回store_id
    """
    last_user_id_file_r = open(last_user_id_file_path, 'r')
    last_user_id = last_user_id_file_r.readline()
    if not last_user_id:
        logger.info("查询上次查询的user_id方法: 这是第一次查询, 返回userID为0")
        return 0
    else:
        logger.info("查询上次查询的user_id方法: 从文件中取得userID为: " + str(last_user_id))
        return last_user_id


def get_last_staff_id():
    """
    获得上次查询到的staffID
    :return: 0 第一次, 非第一次返回store_id
    """
    last_staff_id_file_r = open(last_staff_id_file_path, 'r')
    last_staff_id = last_staff_id_file_r.readline()
    if not last_staff_id:
        logger.info("查询上次查询的staff id方法: 这是第一次查询, 返回staffID为0")
        return 0
    else:
        logger.info("查询上次查询的staff_id方法: 从文件中取得staffID为: " + str(last_staff_id))
        return last_staff_id


def write_last_user_id(user_id):
    """
    写上次查询到的user_id到文件中, 每次都清空文件.
    :param user_id:
    :return: None
    """
    logger.info("写user_id到缓存文件中, 当前user_id为: " + str(get_last_user_id()) + ", 当前写入: " + str(user_id))
    user_id = str(user_id)
    last_user_id_file_w = open(last_user_id_file_path, 'w')
    last_user_id_file_w.write(user_id)


def write_last_staff_id(staff_id):
    """
    写上次查询到的staff_id到文件中, 每次都清空文件.
    :param staff_id:
    :return: None
    """
    logger.info("写staff_id到缓存文件中, 当前staff_id为: " + str(get_last_staff_id()) + ", 当前写入: " + str(staff_id))
    staff_id = str(staff_id)
    last_staff_id_file_w = open(last_staff_id_file_path, 'w')
    last_staff_id_file_w.write(staff_id)


# Import this python file must be run init function.
init()
