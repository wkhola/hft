#! /usr/bin/python
# coding:utf8

import service
from logger import Logger

__author__ = 'CaoYu'
_logger = Logger('user-gather.py')

if __name__ == '__main__':
    _logger.info("----------------------------------------------------------")
    all_user_info_list = service.query_user_info()
    if all_user_info_list:
        _logger.info("查询出一些店主信息, 开始执行插入操作")
        service.insert_user_info(all_user_info_list)
    else:
        _logger.info("本次查询没有查询出[店主]信息, 不进行插入操作")

    all_staff_info_list = service.query_staff_info()
    if all_staff_info_list:
        _logger.info("查询出一些员工信息, 开始执行插入操作")
        service.insert_staff_info(all_staff_info_list)
    else:
        _logger.info("本次查询没有查询出[店主]信息, 不进行插入操作")

    _logger.info("本次执行结束.")
    _logger.info("----------------------------------------------------------")
