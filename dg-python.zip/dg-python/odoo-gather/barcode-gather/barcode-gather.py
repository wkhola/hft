#! /usr/bin/python
# coding:utf8

import service
from logger import Logger

__author__ = 'CaoYu'
_logger = Logger('barcode-gather.py')

if __name__ == '__main__':
    all_barcodes = service.query_barcode()
    if all_barcodes:
        _logger.info("查询出一些条码信息, 开始执行插入操作")
        service.insert_barcode_dw(all_barcodes)
    else:
        _logger.info("本次查询没有查询出条码信息, 不进行插入操作")

    all_shopdatas = service.query_shopdata()
    if all_shopdatas:
        _logger.info("查询出一些中间表数据, 开始执行插入操作")
        service.insert_shopdata_dw(all_shopdatas)
    else:
        _logger.info("本次查询没有查询出新的中间表条码数据, 不进行插入操作")

    all_categories = service.query_category()
    if all_categories:
        _logger.info("查询出一些category表信息, 开始执行插入操作")
        service.insert_category_dw(all_categories)
    else:
        _logger.info("本次查询没有查询出条码信息, 不进行插入操作")

    all_prd_cate_rs = service.query_prd_cate_r()
    if all_prd_cate_rs:
        _logger.info("查询出一些prd_cate_r表信息, 开始执行插入操作")
        service.insert_prd_cate_r_dw(all_prd_cate_rs)
    else:
        _logger.info("本次查询没有查询出条码信息, 不进行插入操作")

    all_prd_pack_rs = service.query_prd_pack_r()
    if all_prd_pack_rs:
        _logger.info("查询出一些条码信息, 开始执行插入操作")
        service.insert_prd_pack_r_dw(all_prd_pack_rs)
    else:
        _logger.info("本次查询没有查询出条码信息, 不进行插入操作")

    all_units = service.query_unit()
    if all_units:
        _logger.info("查询出一些条码信息, 开始执行插入操作")
        service.insert_unit_dw(all_units)
    else:
        _logger.info("本次查询没有查询出条码信息, 不进行插入操作")
    _logger.info("本次执行结束.")
    _logger.info("----------------------------------------------------------")
