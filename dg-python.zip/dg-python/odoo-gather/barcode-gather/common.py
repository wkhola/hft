# coding:utf8

import pymysql as MySQLdb
import ConfigParser
import string
import os
import psycopg2
from logger import Logger

"""
公共组件文件, 包含所有公共方法供使用
"""
__author__ = 'CaoYu'

logger = Logger('common.py')

conf = ConfigParser.ConfigParser()
conf.read("/home/hft/odoo-gather-python-redshift/barcode-gather/config.conf")
last_update_barcode_file_path = conf.get('common', 'last_update_barcode_file_path')
last_update_shopdata_file_path = conf.get('common', 'last_update_shopdata_file_path')
last_update_category_file_path = conf.get('common', 'last_update_category_file_path')
last_update_prd_cate_r_file_path = conf.get('common', 'last_update_prd_cate_r_file_path')
last_update_prd_pack_r_file_path = conf.get('common', 'last_update_prd_pack_r_file_path')
last_update_unit_file_path = conf.get('common', 'last_update_unit_file_path')

# Get connection for mysql
conn_mysql_barcode = MySQLdb.connect(
    host=conf.get('mysql-barcode', 'db_host'),
    port=string.atoi(conf.get('mysql-barcode', 'db_port')),
    user=conf.get('mysql-barcode', 'db_user'),
    passwd=conf.get('mysql-barcode', 'db_password'),
    db=conf.get('mysql-barcode', 'db_db'),
    charset='utf8'
)

# Get connection for postgresql
conn_redshift_datawarehouse = psycopg2.connect(
    host=conf.get('redshift-datawarehouse', 'db_host'),
    port=string.atoi(conf.get('redshift-datawarehouse', 'db_port')),
    user=conf.get('redshift-datawarehouse', 'db_user'),
    password=conf.get('redshift-datawarehouse', 'db_password'),
    database=conf.get('redshift-datawarehouse', 'db_db')
    # charset='utf8'
)


def close_all_connection():
    """
    Close all db connection
    :return: None
    """
    conn_mysql_barcode.close()
    conn_redshift_datawarehouse.close()


def init():
    """
    初始化
    :return:
    """
    if not os.path.exists(last_update_barcode_file_path):
        open(last_update_barcode_file_path, 'a')
        logger.info("缓存上次查询的缓存文件: " + last_update_barcode_file_path + " 不存在, 创建...")

    if not os.path.exists(last_update_shopdata_file_path):
        open(last_update_shopdata_file_path, 'a')
        logger.info("缓存上次查询的缓存文件: " + last_update_shopdata_file_path + " 不存在, 创建...")

    if not os.path.exists(last_update_category_file_path):
        open(last_update_category_file_path, 'a')
        logger.info("缓存上次查询的缓存文件: " + last_update_category_file_path + " 不存在, 创建...")

    if not os.path.exists(last_update_prd_cate_r_file_path):
        open(last_update_prd_cate_r_file_path, 'a')
        logger.info("缓存上次查询的缓存文件: " + last_update_prd_cate_r_file_path + " 不存在, 创建...")

    if not os.path.exists(last_update_prd_pack_r_file_path):
        open(last_update_prd_pack_r_file_path, 'a')
        logger.info("缓存上次查询的缓存文件: " + last_update_prd_pack_r_file_path + " 不存在, 创建...")

    if not os.path.exists(last_update_unit_file_path):
        open(last_update_unit_file_path, 'a')
        logger.info("缓存上次查询的缓存文件: " + last_update_unit_file_path + " 不存在, 创建...")


def get_last_update_barcode():
    """
    获得上次查询到的update barcode
    :return: 0 第一次, 非第一次返回store_id
    """
    last_update_barcode_file_r = open(last_update_barcode_file_path, 'r')
    last_update_barcode = last_update_barcode_file_r.readline()
    if not last_update_barcode:
        logger.info("查询上次查询的更新时间(barcode)方法: 这是第一次查询, 返回为0")
        return '0'
    else:
        logger.info("查询上次查询的更新时间(barcode)方法: 从文件中取得last_update为: " + str(last_update_barcode))
        return str(last_update_barcode).strip()


def get_last_update_shopdata():
    """
    获得上次查询到的update shopdata
    :return: 0 第一次, 非第一次返回store_id
    """
    last_update_shopdata_file_r = open(last_update_shopdata_file_path, 'r')
    last_update_shopdata = last_update_shopdata_file_r.readline()
    if not last_update_shopdata:
        logger.info("查询上次查询的更新时间(shopdata)方法: 这是第一次查询, 返回为0")
        return '0'
    else:
        logger.info("查询上次查询的更新时间(shopdata)方法: 从文件中取得last_update为: " + str(last_update_shopdata))
        return str(last_update_shopdata).strip()


def get_last_update_category():
    """
    获得上次查询到的update category
    :return: 0 第一次, 非第一次返回store_id
    """
    last_update_category_file_r = open(last_update_category_file_path, 'r')
    last_update_category = last_update_category_file_r.readline()
    if not last_update_category:
        logger.info("查询上次查询的更新时间(category)方法: 这是第一次查询, 返回为0")
        return '0'
    else:
        logger.info("查询上次查询的更新时间(category)方法: 从文件中取得last_update为: " + str(last_update_category))
        return str(last_update_category).strip()


def get_last_update_prd_cate_r():
    """
    获得上次查询到的update prd_cate_r
    :return: 0 第一次, 非第一次返回store_id
    """
    last_update_prd_cate_r_file_r = open(last_update_prd_cate_r_file_path, 'r')
    last_update_prd_cate_r = last_update_prd_cate_r_file_r.readline()
    if not last_update_prd_cate_r:
        logger.info("查询上次查询的更新时间(prd_cate_r)方法: 这是第一次查询, 返回为0")
        return '0'
    else:
        logger.info("查询上次查询的更新时间(prd_cate_r)方法: 从文件中取得last_update为: " + str(last_update_prd_cate_r))
        return str(last_update_prd_cate_r).strip()


def get_last_update_prd_pack_r():
    """
    获得上次查询到的update prd_pack_r
    :return: 0 第一次, 非第一次返回store_id
    """
    last_update_prd_pack_r_file_r = open(last_update_prd_pack_r_file_path, 'r')
    last_update_prd_pack_r = last_update_prd_pack_r_file_r.readline()
    if not last_update_prd_pack_r:
        logger.info("查询上次查询的更新时间(prd_pack_r)方法: 这是第一次查询, 返回为0")
        return '0'
    else:
        logger.info("查询上次查询的更新时间(prd_pack_r)方法: 从文件中取得last_update为: " + str(last_update_prd_pack_r))
        return str(last_update_prd_pack_r).strip()


def get_last_update_unit():
    """
    获得上次查询到的update unit
    :return: 0 第一次, 非第一次返回store_id
    """
    last_update_unit_file_r = open(last_update_unit_file_path, 'r')
    last_update_unit = last_update_unit_file_r.readline()
    if not last_update_unit:
        logger.info("查询上次查询的更新时间(unit)方法: 这是第一次查询, 返回为0")
        return '0'
    else:
        logger.info("查询上次查询的更新时间(unit)方法: 从文件中取得last_update为: " + str(last_update_unit))
        return str(last_update_unit).strip()


def write_last_update_barcode(last_update):
    """
    写上次查询到的last_update barcode到文件中, 每次都清空文件.
    :param last_update:
    :return: None
    """
    logger.info("写last_update(barcode)到缓存文件中, 当前last_update为: " +
                str(get_last_update_barcode()) + ", 当前写入: " + str(last_update))
    last_update = str(last_update)
    last_update_barcode_file_w = open(last_update_barcode_file_path, 'w')
    last_update_barcode_file_w.write(last_update)


def write_last_update_shopdata(last_update):
    """
    写上次查询到的last_update shopdata到文件中, 每次都清空文件.
    :param last_update:
    :return: None
    """
    logger.info("写last_update(shopdata)到缓存文件中, 当前last_update为: " +
                str(get_last_update_shopdata()) + ", 当前写入: " + str(last_update))
    last_update = str(last_update)
    last_update_shopdata_file_w = open(last_update_shopdata_file_path, 'w')
    last_update_shopdata_file_w.write(last_update)


def write_last_update_category(last_update):
    """
    写上次查询到的last_update category到文件中, 每次都清空文件.
    :param last_update:
    :return: None
    """
    logger.info("写last_update(category)到缓存文件中, 当前last_update为: " +
                str(get_last_update_category()) + ", 当前写入: " + str(last_update))
    last_update = str(last_update)
    last_update_category_file_w = open(last_update_category_file_path, 'w')
    last_update_category_file_w.write(last_update)


def write_last_update_prd_cate_r(last_update):
    """
    写上次查询到的last_update prd_cate_r到文件中, 每次都清空文件.
    :param last_update:
    :return: None
    """
    logger.info("写last_update(prd_cate_r)到缓存文件中, 当前last_update为: " +
                str(get_last_update_prd_cate_r()) + ", 当前写入: " + str(last_update))
    last_update = str(last_update)
    last_update_prd_cate_r_file_w = open(last_update_prd_cate_r_file_path, 'w')
    last_update_prd_cate_r_file_w.write(last_update)


def write_last_update_prd_pack_r(last_update):
    """
    写上次查询到的last_update prd_pack_r到文件中, 每次都清空文件.
    :param last_update:
    :return: None
    """
    logger.info("写last_update(prd_pack_r)到缓存文件中, 当前last_update为: " +
                str(get_last_update_prd_pack_r()) + ", 当前写入: " + str(last_update))
    last_update = str(last_update)
    last_update_prd_pack_r_file_w = open(last_update_prd_pack_r_file_path, 'w')
    last_update_prd_pack_r_file_w.write(last_update)


def write_last_update_unit(last_update):
    """
    写上次查询到的last_update unit到文件中, 每次都清空文件.
    :param last_update:
    :return: None
    """
    logger.info("写last_update(unit)到缓存文件中, 当前last_update为: " +
                str(get_last_update_unit()) + ", 当前写入: " + str(last_update))
    last_update = str(last_update)
    last_update_unit_file_w = open(last_update_unit_file_path, 'w')
    last_update_unit_file_w.write(last_update)


# Import this python file must be run init function.
init()
