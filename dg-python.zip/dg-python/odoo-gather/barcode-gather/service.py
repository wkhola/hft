# coding:utf8

import common
import sys
from logger import Logger
__author__ = 'Caoyu'
default_encoding = 'utf-8'
if sys.getdefaultencoding() != default_encoding:
    reload(sys)
    sys.setdefaultencoding(default_encoding)
_logger = Logger("service.py")
conn_mysql_barcode = common.conn_mysql_barcode


def query_barcode():
    """
    查询条码信息, from barcode总表
    :return: all barcode list
    """
    last_update_barcode = common.get_last_update_barcode()
    sql = "SELECT code, name, spec, specnum, trademark, addr, units, factory_name, " \
          "trade_price, retail_price, updateAt, wholeunit, wholenum, img, src, unit_id, code2," \
          " name2, factory_name2, trademark2, spec2, addr2, expiration_date, expiration_date_unit, " \
          "status, issame, batch, is_pack, is_high " \
          "FROM sys_barcode WHERE updateAt > '" + last_update_barcode + "'"
    cursor = conn_mysql_barcode.cursor()
    cursor.execute(sql)
    result = cursor.fetchall()

    all_barcodes = []

    for single_barcode_info in result:
        single_barcode_info_dict = dict()

        single_barcode_info_dict['code'] = single_barcode_info[0]
        single_barcode_info_dict['name'] = single_barcode_info[1]
        single_barcode_info_dict['spec'] = single_barcode_info[2]
        single_barcode_info_dict['specnum'] = single_barcode_info[3]
        single_barcode_info_dict['trademark'] = single_barcode_info[4]
        single_barcode_info_dict['addr'] = single_barcode_info[5]
        single_barcode_info_dict['units'] = single_barcode_info[6]
        single_barcode_info_dict['factory_name'] = single_barcode_info[7]
        single_barcode_info_dict['trade_price'] = single_barcode_info[8]
        single_barcode_info_dict['retail_price'] = single_barcode_info[9]
        single_barcode_info_dict['updateAt'] = single_barcode_info[10]
        single_barcode_info_dict['wholeunit'] = single_barcode_info[11]
        single_barcode_info_dict['wholenum'] = single_barcode_info[12]
        single_barcode_info_dict['img'] = single_barcode_info[13]
        single_barcode_info_dict['src'] = single_barcode_info[14]

        single_barcode_info_dict['unit_id'] = single_barcode_info[15]
        single_barcode_info_dict['code2'] = single_barcode_info[16]
        single_barcode_info_dict['name2'] = single_barcode_info[17]
        single_barcode_info_dict['factory_name2'] = single_barcode_info[18]
        single_barcode_info_dict['trademark2'] = single_barcode_info[19]
        single_barcode_info_dict['spec2'] = single_barcode_info[20]
        single_barcode_info_dict['addr2'] = single_barcode_info[21]
        single_barcode_info_dict['expiration_date'] = single_barcode_info[22]
        single_barcode_info_dict['expiration_date_unit'] = single_barcode_info[23]
        single_barcode_info_dict['status'] = single_barcode_info[24]
        single_barcode_info_dict['issame'] = single_barcode_info[25]
        single_barcode_info_dict['batch'] = single_barcode_info[26]
        single_barcode_info_dict['is_pack'] = single_barcode_info[27]
        single_barcode_info_dict['is_high'] = single_barcode_info[28]


        all_barcodes.append(single_barcode_info_dict)

    _logger.info("查询barcode信息成功, 从时间: " + last_update_barcode +
                 "开始, 查询出: " + str(len(all_barcodes)) + "条条码信息.")
    return all_barcodes


def query_shopdata():
    """
    查询条码信息, from sys_shopdata表
    因为这个表大, 不适合用一整个对象存储所有信息然后再插入, 只能边查询边插入了
    :return: all_shopdata_list
    """
    last_update_shopdata = common.get_last_update_shopdata()
    sql = "SELECT shop_id, code, name, spec, trademark, units, factory_name, " \
          "addr, img, trade_price, retail_price, status_id, updateAt, " \
          "repertory, is_standard_barcode, affirm_price, up_down_shelves, " \
          "expiry_date, proportion, is_child, is_config, unit_id, brevity " \
          "FROM sys_shopdata " \
          "WHERE updateAt > '" + last_update_shopdata + "' ORDER BY updateAt"
    cursor = conn_mysql_barcode.cursor()
    cursor.execute(sql)
    result = cursor.fetchall()

    all_shopdatas = []

    for r in result:
        single_info = dict()

        single_info['shop_id'] = r[0]
        single_info['code'] = r[1]
        single_info['name'] = r[2]
        single_info['spec'] = r[3]
        single_info['trademark'] = r[4]
        single_info['units'] = r[5]
        single_info['factory_name'] = r[6]
        single_info['addr'] = r[7]
        single_info['img'] = r[8]
        single_info['trade_price'] = r[9]
        single_info['retail_price'] = r[10]
        single_info['status_id'] = r[11]
        single_info['updateAt'] = r[12]
        single_info['repertory'] = r[13]
        single_info['is_standard_barcode'] = r[14]
        single_info['affirm_price'] = r[15]

        single_info['up_down_shelves'] = r[16]
        single_info['expiry_date'] = r[17]
        single_info['proportion'] = r[18]
        single_info['is_child'] = r[19]
        single_info['is_config'] = r[20]
        single_info['unit_id'] = r[21]
        single_info['brevity'] = r[22]

        all_shopdatas.append(single_info)

    _logger.info("查询shopdata成功, 从: " + last_update_shopdata +
                 "开始, 共查询到: " + str(len(all_shopdatas)) + "条中间表数据")
    return all_shopdatas


def query_category():
    """
    查询条码信息, from category表
    :return: all category list
    """
    last_update_category = common.get_last_update_category()
    sql = "SELECT id, pid, title, alias, is_parent, status, sort " \
          "FROM category WHERE id > '" + last_update_category + "'"
    cursor = conn_mysql_barcode.cursor()
    cursor.execute(sql)
    result = cursor.fetchall()

    all_categories = []

    for r in result:
        single_info_dict = dict()

        single_info_dict['id'] = r[0]
        single_info_dict['pid'] = r[1]
        single_info_dict['title'] = r[2]
        single_info_dict['alias'] = r[3]
        single_info_dict['is_parent'] = r[4]
        single_info_dict['status'] = r[5]
        single_info_dict['sort'] = r[6]

        all_categories.append(single_info_dict)

    _logger.info("查询category信息成功, 从: " + last_update_category +
                 "开始, 查询出: " + str(len(all_categories)) + "条信息.")
    return all_categories


def query_prd_cate_r():
    """
    查询条码信息, from prd_cate_r总表
    :return: all prd_cate_r list
    """
    last_update_prd_cate_r = common.get_last_update_prd_cate_r()
    sql = "SELECT id, code, category_id " \
          "FROM prd_cate_r WHERE id > '" + last_update_prd_cate_r + "'"
    cursor = conn_mysql_barcode.cursor()
    cursor.execute(sql)
    result = cursor.fetchall()

    all_prd_cate_rs = []

    for single_info in result:
        single_info_dict = dict()

        single_info_dict['id'] = single_info[0]
        single_info_dict['code'] = single_info[1]
        single_info_dict['category_id'] = single_info[2]

        all_prd_cate_rs.append(single_info_dict)

    _logger.info("查询prd_cate_r信息成功, 从: " + last_update_prd_cate_r +
                 "开始, 查询出: " + str(len(all_prd_cate_rs)) + "条信息.")
    return all_prd_cate_rs


def query_prd_pack_r():
    """
    查询条码信息, from prd_pack_r表
    :return: all prd_pack_r list
    """
    last_update_prd_pack_r = common.get_last_update_prd_pack_r()
    sql = "SELECT id, pack_code, pack_name, type, prd_code, pack_proportion, shop_id " \
          "FROM prd_pack_r WHERE id > '" + last_update_prd_pack_r + "'"
    cursor = conn_mysql_barcode.cursor()
    cursor.execute(sql)
    result = cursor.fetchall()

    all_prd_pack_rs = []

    for r in result:
        single_info_dict = dict()

        single_info_dict['id'] = r[0]
        single_info_dict['pack_code'] = r[1]
        single_info_dict['pack_name'] = r[2]
        single_info_dict['type'] = r[3]
        single_info_dict['prd_code'] = r[4]
        single_info_dict['pack_proportion'] = r[5]
        single_info_dict['shop_id'] = r[6]

        all_prd_pack_rs.append(single_info_dict)

    _logger.info("查询prd_pack_r信息成功, 从: " + last_update_prd_pack_r +
                 "开始, 查询出: " + str(len(all_prd_pack_rs)) + "条信息.")
    return all_prd_pack_rs


def query_unit():
    """
    查询条码信息, from unit表
    :return: all unit list
    """
    last_update_unit = common.get_last_update_unit()
    sql = "SELECT id, shop_id,category_id, name, status, content, proportion " \
          "FROM unit WHERE id > '" + last_update_unit + "'"
    cursor = conn_mysql_barcode.cursor()
    cursor.execute(sql)
    result = cursor.fetchall()

    all_units = []

    for r in result:
        single_info_dict = dict()

        single_info_dict['id'] = r[0]
        single_info_dict['shop_id'] = r[1]
        single_info_dict['category_id'] = r[2]
        single_info_dict['name'] = r[3]
        single_info_dict['status'] = r[4]
        single_info_dict['content'] = r[5]
        single_info_dict['proportion'] = r[6]

        all_units.append(single_info_dict)

    _logger.info("查询unit信息成功, 从: " + last_update_unit +
                 "开始, 查询出: " + str(len(all_units)) + "条信息.")
    return all_units


def insert_barcode_dw(all_barcodes):
    conn_mysql_dw = common.conn_redshift_datawarehouse
    cursor = conn_mysql_dw.cursor()
    count = 0
    max_last_update = ''
    last_run_update = ''
    try:
        for single_barcode_info_dict in all_barcodes:
            code = single_barcode_info_dict['code']
            name = single_barcode_info_dict['name'].replace("'", "").replace("\\", "") if single_barcode_info_dict['name'] else ''
            spec = single_barcode_info_dict['spec'].replace("'", "").replace("\\", "") if single_barcode_info_dict['spec'] else ''

            specnum = single_barcode_info_dict['specnum'] if single_barcode_info_dict['specnum'] else 0

            trademark = single_barcode_info_dict['trademark'].replace("'", "").replace("\\", "") if single_barcode_info_dict['trademark'] else ''
            addr = single_barcode_info_dict['addr'].replace("'", "").replace("\\", "") if single_barcode_info_dict['addr'] else ''
            units = single_barcode_info_dict['units'].replace("'", "").replace("\\", "") if single_barcode_info_dict['units'] else ''
            factory_name = single_barcode_info_dict['factory_name'].replace("'", "").replace("\\", "") if single_barcode_info_dict['factory_name'] else ''
            trade_price = single_barcode_info_dict['trade_price'].replace("'", "").replace("\\", "") if single_barcode_info_dict['trade_price'] else ''
            retail_price = single_barcode_info_dict['retail_price'].replace("'", "").replace("\\", "") if single_barcode_info_dict['retail_price'] else ''
            updateAt = single_barcode_info_dict['updateAt'] if single_barcode_info_dict['updateAt'] else ''
            wholeunit = single_barcode_info_dict['wholeunit'].replace("'", "").replace("\\", "") if single_barcode_info_dict['wholeunit'] else ''
            wholenum = single_barcode_info_dict['wholenum'] if single_barcode_info_dict['wholenum'] else 0
            img = single_barcode_info_dict['img'].replace("'", "").replace("\\", "") if single_barcode_info_dict['img'] else ''
            src = single_barcode_info_dict['src'].replace("'", "").replace("\\", "") if single_barcode_info_dict['src'] else ''

            unit_id = single_barcode_info_dict['unit_id'] if single_barcode_info_dict['unit_id'] else 0
            code2 = single_barcode_info_dict['code2'].replace("'", "").replace("\\", "") if single_barcode_info_dict['code2'] else ''
            name2 = single_barcode_info_dict['name2'].replace("'", "").replace("\\", "") if single_barcode_info_dict['name2'] else ''
            factory_name2 = single_barcode_info_dict['factory_name2'].replace("'", "").replace("\\", "") if single_barcode_info_dict['factory_name2'] else ''
            trademark2 = single_barcode_info_dict['trademark2'].replace("'", "").replace("\\", "") if single_barcode_info_dict['trademark2'] else ''
            spec2 = single_barcode_info_dict['spec2'].replace("'", "").replace("\\", "") if single_barcode_info_dict['spec2'] else ''
            addr2 = single_barcode_info_dict['addr2'].replace("'", "").replace("\\", "") if single_barcode_info_dict['addr2'] else ''
            expiration_date = single_barcode_info_dict['expiration_date'] if single_barcode_info_dict['expiration_date'] else 0
            expiration_date_unit = single_barcode_info_dict['expiration_date_unit'] if single_barcode_info_dict['expiration_date_unit'] else 0
            status = single_barcode_info_dict['status'] if single_barcode_info_dict['status'] else 0
            issame = single_barcode_info_dict['issame'] if single_barcode_info_dict['issame'] else 0
            batch = single_barcode_info_dict['batch'] if single_barcode_info_dict['batch'] else 0
            is_pack = single_barcode_info_dict['is_pack'] if single_barcode_info_dict['is_pack'] else 0
            is_high = single_barcode_info_dict['is_high'] if single_barcode_info_dict['is_high'] else 0

            if str(updateAt) > max_last_update:
                max_last_update = str(updateAt)

            sql = "INSERT INTO `barcode`(code, name, spec, specnum, trademark, addr, units, " \
                  "factory_name, trade_price, retail_price, updateAt, wholeunit, wholenum, " \
                  "img, src, unit_id, code2, name2, factory_name2, trademark2, spec2, " \
                  "addr2, expiration_date, expiration_date_unit, status, issame, batch, " \
                  "is_pack, is_high) VALUES('%s', '%s', '%s', %d, '%s', '%s', '%s', '%s'," \
                  "'%s', '%s', '%s', '%s', %d, '%s', '%s',%d, '%s', '%s', '%s', '%s', '%s', '%s'" \
                  ", %d, %d, %d, %d, %d, %d, %d)" % \
                  (code, name, spec, specnum, trademark, addr, units, factory_name,
                   trade_price, retail_price, updateAt, wholeunit, wholenum, img, src, unit_id,
                   code2, name2, factory_name2, trademark2, spec2,
                   addr2, expiration_date, expiration_date_unit, status, issame, batch, is_pack, is_high)
            cursor.execute(sql)
            conn_mysql_dw.commit()
            count += 1
            _logger.info(str(count) + ", 插入一条barcode信息到数据仓库, code: " + code + ", name: " + name)
            last_run_update = updateAt
    except Exception, e:
        _logger.error("准备数据并插入数据到数据仓库出错(barcode)  "
                      "写入上一条执行的最后更新时间到缓存中:  " + str(last_run_update))
        _logger.exception(e)
        common.write_last_update_barcode(last_run_update)
        return False

    common.write_last_update_barcode(max_last_update)
    return True


def insert_shopdata_dw(all_shopdatas):
    """
    插入中间表数据到数据仓库中
    :param all_shopdatas:
    :return:
    """
    conn_mysql_dw = common.conn_redshift_datawarehouse
    cursor = conn_mysql_dw.cursor()
    count = 0
    max_last_update = ''
    last_run_update = ''
    try:
        for single_info in all_shopdatas:
            shop_id = single_info['shop_id']
            code = single_info['code']
            name = single_info['name'].replace("'", "").replace("\\", "") if single_info['name'] else ''
            spec = single_info['spec'].replace("'", "").replace("\\", "") if single_info['spec'] else ''
            trademark = single_info['trademark'].replace("'", "").replace("\\", "") if single_info['trademark'] else ''
            units = single_info['units'].replace("'", "").replace("\\", "") if single_info['units'] else ''
            factory_name = single_info['factory_name'].replace("'", "").replace("\\", "") if single_info['factory_name'] else ''
            addr = single_info['addr'].replace("'", "").replace("\\", "") if single_info['addr'] else ''
            img = single_info['img'].replace("'", "").replace("\\", "") if single_info['img'] else ''
            trade_price = single_info['trade_price'] if single_info['trade_price'] else '0.00'
            retail_price = single_info['retail_price'] if single_info['retail_price'] else '0.00'
            status_id = single_info['status_id'] if single_info['status_id'] else 0
            updateAt = single_info['updateAt'] if single_info['updateAt'] else ''
            repertory = single_info['repertory'] if single_info['repertory'] else 0
            is_standard_barcode = single_info['is_standard_barcode'] if single_info['is_standard_barcode'] else 0
            affirm_price = single_info['affirm_price'] if single_info['affirm_price'] else 0

            up_down_shelves = single_info['up_down_shelves'] if single_info['up_down_shelves'] else 0
            expiry_date = single_info['expiry_date'] if single_info['expiry_date'] else 0
            proportion = single_info['proportion'] if single_info['proportion'] else 0
            is_child = single_info['is_child'] if single_info['is_child'] else 0
            is_config = single_info['is_config'] if single_info['is_config'] else 0
            unit_id = single_info['unit_id'] if single_info['unit_id'] else 0
            brevity = single_info['brevity'].replace("'", "").replace("\\", "") if single_info['brevity'] else ''

            if str(updateAt) > max_last_update:
                max_last_update = str(updateAt)

            sql = "INSERT INTO `shopdata`(shop_id, code, name, spec, trademark, units, " \
                  "factory_name, addr, img, trade_price, retail_price, status_id, " \
                  "updateAt, repertory, is_standard_barcode, affirm_price, up_down_shelves, expiry_date, " \
                  "proportion, is_child, is_config, unit_id, brevity) VALUES(" \
                  "'%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', %d, " \
                  "'%s', %d, %d, %d, %d, %d, %d, %d, %d, %d, '%s')"\
                  % (shop_id, code, name, spec, trademark, units, factory_name, addr, img, trade_price, retail_price,
                     status_id, updateAt, repertory, is_standard_barcode, affirm_price, up_down_shelves, expiry_date,
                     proportion, is_child, is_config, unit_id, brevity)
            cursor.execute(sql)
            conn_mysql_dw.commit()
            count += 1
            _logger.info(str(count) + ", 插入一条shopdata信息到数据仓库, code: " + code + ", name: " + name)
            last_run_update = updateAt
    except Exception, e:
        _logger.error("准备数据并插入数据到数据仓库出错(shopdata), "
                      "写入上一条执行的最后更新时间到缓存中:  " + str(last_run_update))
        _logger.exception(e)
        common.write_last_update_shopdata(last_run_update)
        return False

    common.write_last_update_shopdata(max_last_update)
    return True


def insert_category_dw(all_categoyies):
    """
    插入category表数据到数据仓库中
    :param all_categories:
    :return:
    """
    conn_mysql_dw = common.conn_redshift_datawarehouse
    cursor = conn_mysql_dw.cursor()
    count = 0
    max_last_update = 0
    last_run_update = 0
    try:
        for single_info in all_categoyies:
            id = single_info['id']
            pid = single_info['pid'] if single_info['pid'] else 0
            title = single_info['title'].replace("'", "").replace("\\", "") if single_info['title'] else ''
            alias = single_info['alias'].replace("'", "").replace("\\", "") if single_info['alias'] else ''
            is_parent = single_info['is_parent'] if single_info['is_parent'] else 0
            status = single_info['status'] if single_info['status'] else 0
            sort = single_info['sort'] if single_info['sort'] else 0

            if str(id) > max_last_update:
                max_last_update = str(id)

            sql = "INSERT INTO `category`(id, pid, title, alias, is_parent, status, " \
                  "sort) VALUES(%d, %d, '%s', '%s', %d, %d, %d)" \
                  % (id, pid, title, alias, is_parent, status, sort)
            cursor.execute(sql)
            conn_mysql_dw.commit()
            count += 1
            _logger.info(str(count) + ", 插入一条category信息到数据仓库, id: " + str(id) + ", title: " + title)
            last_run_update = id
    except Exception, e:
        _logger.error("准备数据并插入数据到数据仓库出错(barcode), "
                      "写入上一条执行的最后更新id到缓存中:  " + str(last_run_update))
        _logger.exception(e)
        common.write_last_update_category(last_run_update)
        return False

    common.write_last_update_category(max_last_update)
    return True


def insert_prd_cate_r_dw(all_prd_cate_rs):
    """
    插入prd_cate_r表数据到数据仓库中
    :param all_prd_cate_rs:
    :return:
    """
    conn_mysql_dw = common.conn_redshift_datawarehouse
    cursor = conn_mysql_dw.cursor()
    count = 0
    max_last_update = 0
    last_run_update = 0
    try:
        for single_info in all_prd_cate_rs:
            id = single_info['id']
            code = single_info['code'].replace("'", "").replace("\\", "") if single_info['code'] else ''
            category_id = single_info['category_id'] if single_info['category_id'] else 0


            if str(id) > max_last_update:
                max_last_update = str(id)

            sql = "INSERT INTO `prd_cate_r`(id, code, category_id) VALUES(" \
                  "%d, '%s', %d)" \
                  % (id, code, category_id)
            cursor.execute(sql)
            conn_mysql_dw.commit()
            count += 1
            _logger.info(str(count) + ", 插入一条prd_cate_r信息到数据仓库, id: " + str(id) + ", code: " + code)
            last_run_update = id
    except Exception, e:
        _logger.error("准备数据并插入数据到数据仓库出错(prd_cate_r), "
                      "写入上一条执行的最后更新id到缓存中:  " + str(last_run_update))
        _logger.exception(e)
        common.write_last_update_prd_cate_r(last_run_update)
        return False

    common.write_last_update_prd_cate_r(max_last_update)
    return True


def insert_prd_pack_r_dw(all_prd_pack_rs):
    """
    插入prd_cate_r表数据到数据仓库中
    :param all_prd_pack_rs:
    :return:
    """
    conn_mysql_dw = common.conn_redshift_datawarehouse
    cursor = conn_mysql_dw.cursor()
    count = 0
    max_last_update = 0
    last_run_update = 0
    try:
        for single_info in all_prd_pack_rs:
            id = single_info['id']
            pack_code = single_info['pack_code'].replace("'", "").replace("\\", "") if single_info['pack_code'] else ''
            pack_name = single_info['pack_name'].replace("'", "").replace("\\", "") if single_info['pack_name'] else ''
            type = single_info['type'] if single_info['type'] else 0
            prd_code = single_info['prd_code'].replace("'", "").replace("\\", "") if single_info['prd_code'] else ''
            pack_proportion = single_info['pack_proportion'] if single_info['pack_proportion'] else 0
            shop_id = single_info['shop_id'] if single_info['shop_id'] else ''


            if str(id) > max_last_update:
                max_last_update = str(id)

            sql = "INSERT INTO `prd_pack_r`(id, pack_code, pack_name, type, prd_code, pack_proportion, " \
                  "shop_id) VALUES(" \
                  "%d, '%s', '%s', %d, '%s', %d, '%s')" \
                  % (id, pack_code, pack_name, type, prd_code, pack_proportion, shop_id)
            cursor.execute(sql)
            conn_mysql_dw.commit()
            count += 1
            _logger.info(str(count) + ", 插入一条prd_pack_r信息到数据仓库, id: " + str(id) + ", pack_code: " + pack_code)
            last_run_update = id
    except Exception, e:
        _logger.error("准备数据并插入数据到数据仓库出错(prd_cate_r), "
                      "写入上一条执行的最后更新id到缓存中:  " + str(last_run_update))
        _logger.exception(e)
        common.write_last_update_prd_pack_r(last_run_update)
        return False

    common.write_last_update_prd_pack_r(max_last_update)
    return True


def insert_unit_dw(units):
    """
    插入unit表数据到数据仓库中
    :param all_units:
    :return:
    """
    conn_mysql_dw = common.conn_redshift_datawarehouse
    cursor = conn_mysql_dw.cursor()
    count = 0
    max_last_update = 0
    last_run_update = 0
    try:
        for single_info in units:
            id = single_info['id']
            shop_id = single_info['shop_id'] if single_info['shop_id'] else 0
            category_id = single_info['category_id'] if single_info['category_id'] else 0
            name = single_info['name'].replace("'", "").replace("\\", "") if single_info['name'] else ''
            status = single_info['status'] if single_info['status'] else 0
            content = single_info['content'].replace("'", "").replace("\\", "") if single_info['content'] else ''
            proportion = single_info['proportion'] if single_info['proportion'] else 0

            if str(id) > max_last_update:
                max_last_update = str(id)

            sql = "INSERT INTO `unit`(id, shop_id, category_id, name, status, content, " \
                  "proportion) VALUES(" \
                  "%d, %d, %d, '%s', %d, '%s', %d)" \
                  % (id, shop_id, category_id, name, status, content, proportion)
            cursor.execute(sql)
            conn_mysql_dw.commit()
            count += 1
            _logger.info( ", 插入一条unit信息到数据仓库,id: " + str(id) + ", shop_id: " + str(shop_id))
            last_run_update = id
    except Exception, e:
        _logger.error("准备数据并插入数据到数据仓库出错(unit), "
                      "写入上一条执行的最后更新id到缓存中:  " + str(last_run_update))
        _logger.exception(e)
        common.write_last_update_unit(last_run_update)
        return False

    common.write_last_update_unit(max_last_update)
    return True
