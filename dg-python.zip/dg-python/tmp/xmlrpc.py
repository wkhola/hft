# coding:utf8
import datetime
import ssl
import xmlrpclib
import time
import json

# 演示环境
# portal_url = 'https://hft-demo.esmart365.com'
# portal_db = 'hft-demo.esmart365.com'
# admin_username = 'admin'
# admin_password = '2212072ok1'

# 生产环境
portal_url = 'https://portal.hft-pro.esmart365.com'
portal_db = 'portal.hft-pro.esmart365.com'
admin_username = 'admin'
admin_password = 'Qeuts23hfu3906AejseiGOOD'

# 测试用测试环境
# portal_url = 'https://saas.odoo-stagin.esmart365.com'
# portal_db = 'saas.odoo-stagin.esmart365.com'
# admin_username = 'admin'
# admin_password = '123456'


# 集成开发环境
# portal_url = 'https://portal.saas.odoo-server.corp.esmart365.com'
# portal_db = 'portal.saas.odoo-server.corp.esmart365.com'
# admin_username = 'admin'
# admin_password = '123456'

# context = ssl._create_unverified_context()
common = xmlrpclib.ServerProxy('{}/xmlrpc/2/common'.format(portal_url))
admin_uid = common.authenticate(portal_db, admin_username, admin_password, {})
models = xmlrpclib.ServerProxy('{}/xmlrpc/2/object'.format(portal_url))


hot = {
    'start_time': 1516118461,
    'end_time': 1516201261,
    'top_num': 10,
    'store_id': 12
}

q = {
    "code" : '6901236341582',
    "store_id": 90
}
login = {
    'password': '5b113508dfaee3719a3443e9ef59766bac60948e',
    'phone_num':'15917920318',
    'store_id': 292
}
a = models.execute_kw(portal_db, admin_uid, admin_password, 'shop.pos_mac_sn',
                      'get_sn_by_mac', [], {"mac": "00:95:69:c6:76:e3"})
print a
# a = models.execute(portal_db, admin_uid, admin_password, 'kite.summsgrecord', 'get_infos', [], cpuids)


new_staff = {
    'phone_num': '13528422603',
    'name': '重复手机号能新增22112131233332?',
    'password': '123321',
    'init_permissions': [1, 2],
    'store_id': 12

}

new_user = {
'phone_num' : '18500233007',
'name': 'qqq',
'password': '123333',
'init_permissions': [1, 2],
'store_id': 177
}

create = {"product": [
         {
              "code": "123456",    #商品条码
              "count": 3,             #商品购买数量
              "price_per": 12      #商品单价
          },
         {
              "code": "345678",    #商品条码
              "count": 3,             #商品购买数量
              "price_per": 12      #商品单价
          }
    ],
         "payment": {
                 "total_no_discount": 96,   #折扣前总价 类型数字
                 "discount": 3,                    #折扣数 类型数字
                  "receivable" : 93,             #应收 类型数字
                 "payed_total": 95,             #实际付款  类型数字
                 "small_change": 2,           #找零  类型数字
                 "pay_type":                  #支付类型, key/value形式的字典
                                 {
                                 "name": "cash",  #现金  类型字符串  “wechat” 微信支付, “alipay” 支付宝支付
                                 "payed": "93"      #付款金额  类型数字
                                }

          },
         "date": "20170725 12:23:33", #时间   类型字符串
         "operator":  "asdasd-asd-asdasd-sadas-dasd-asdsad",                    # 用户user_uuid  类型字符串
         "day_order_seq": 3,               #日单数  类型数字
         "order_id":  "1233312311123",               # 订单ID  字符串
         "store_id": 177,                           #店铺ID   必传 毋忘
         "is_signed": 0                         #是否签约开通微信，支付宝扫码支付服务， 1 开通， 0 不开通

}