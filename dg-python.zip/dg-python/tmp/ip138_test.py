#! /usr/bin/python
# coding:utf8
import requests
import sys

__author__ = 'CaoYu'
reload(sys)
sys.setdefaultencoding('utf8')


def request_get(url):
    headers = {'Content-Type': 'application/json'}
    # headers = {'Content-Type': 'application/json', 'token': 'b571171c024d8400633c75561a926089'}
    result = requests.get(url=url, headers=headers)
    result.encoding = 'gbk'
    return result.text


def request_post(url, data):
    headers = {'Content-Type': 'application/json'}
    result = requests.post(url=url, data=data, headers=headers)
    return result.json()


url = 'http://www.ip138.com/ips138.asp?ip=36.109.123.22&action=2'

ips = []
# ips.append('14.155.158.83')
# ips.append('14.153.78.42')
# ips.append('14.221.167.7')
# ips.append('183.39.87.136')
# ips.append('183.17.55.194')
# ips.append('119.137.103.211')
# ips.append('112.97.61.163')
# ips.append('183.11.71.145')
# ips.append('183.39.45.213')
# ips.append('14.153.186.140')
# ips.append('14.155.29.90')
# ips.append('121.35.186.56')
# ips.append('183.13.159.246')
# ips.append('112.97.57.169')
# ips.append('114.254.223.0')
# ips.append('113.89.8.160')
# ips.append('183.14.28.220')
# ips.append('113.87.45.33')
# ips.append('61.141.74.68')
# ips.append('183.37.230.255')
# ips.append('27.38.32.133')
# ips.append('183.14.133.202')
# ips.append('27.38.21.15')
# ips.append('113.88.161.48')
# ips.append('1.2.3.9')
# ips.append('36.109.123.22')
# ips.append('61.244.148.166')
# ips.append('202.175.34.1')
# ips.append('202222.175.34.1')
# ips.append('223.104.6.19')
ips.append("1.180.207.252")

for ip in ips:
    url = 'http://www.ip138.com/ips138.asp?ip=%s&action=2' % (ip)
    result = request_get(url)
    a = result.find('本站数据')
    b = result.find('</li>', a)
    area = result[a: b].split('：')[1].split('  ')[0].split(' ')[0]
    is_sheng = area.find('省')
    if not is_sheng == -1:
        region = area.split('省')[0] + '省'
        city = area.split('省')[1]
        print region, city
        continue
    is_qu = area.find('自治区')
    if not is_qu == -1:
        region = area.split('自治区')[0] + '自治区'
        city = area.split('自治区')[1]
        print region, city
        continue

    is_zhixiashi = area.count('市')
    if is_zhixiashi > 1:
        region = area.split('市')[0] + '市'
        city = area.split('市')[1] + '市'
        print region, city
        continue

    is_xingzhengqu = area.find('行政区')
    if not is_xingzhengqu == -1:
        region = area.split('行政区')[0] + '行政区'
        city = region.replace('特别', '').replace('行政区', '') + '市'
        print region, city
        continue

    is_single_city = area.count('市')
    if is_single_city == 1:
        region = area.split('市')[0] + '市'
        city = area.split('市')[0] + '市'
        print region, city
        continue
