#! /usr/bin/python
# coding:utf8

__author__ = 'Caoyu'

import MySQLdb

conn_flask = MySQLdb.connect(
    host="40.125.170.251",
    port=3306,
    user="nodejs",
    passwd="Nodejs@odoo123.com",
    db="hfttest",
    charset='utf8'
)

conn_dw = MySQLdb.connect(
    host="hftdw.mysqldb.chinacloudapi.cn",
    port=3306,
    user="hftdw%odoo",
    passwd="CAOB29PM558yu",
    db="odoo",
    charset='utf8'
)

cursor_flask = conn_flask.cursor()
cursor_dw = conn_dw.cursor()


def insert_shopdata_dw(all_shopdatas):
    insert_list = list()
    for single_info in all_shopdatas:
        shop_id = single_info['shop_id']
        code = single_info['code']
        name = single_info['name'].replace("'", "").replace("\\", "") if single_info['name'] else ''
        spec = single_info['spec'].replace("'", "").replace("\\", "") if single_info['spec'] else ''
        trademark = single_info['trademark'].replace("'", "").replace("\\", "") if single_info['trademark'] else ''
        units = single_info['units'].replace("'", "").replace("\\", "") if single_info['units'] else ''
        factory_name = single_info['factory_name'].replace("'", "").replace("\\", "") if single_info[
            'factory_name'] else ''
        addr = single_info['addr'].replace("'", "").replace("\\", "") if single_info['addr'] else ''
        img = single_info['img'].replace("'", "").replace("\\", "") if single_info['img'] else ''
        trade_price = single_info['trade_price'] if single_info['trade_price'] else '0.00'
        retail_price = single_info['retail_price'] if single_info['retail_price'] else '0.00'
        status_id = single_info['status_id'] if single_info['status_id'] else 0
        updateAt = single_info['updateAt'] if single_info['updateAt'] else ''
        repertory = single_info['repertory'] if single_info['repertory'] else 0
        is_standard_barcode = single_info['is_standard_barcode'] if single_info['is_standard_barcode'] else 0
        affirm_price = single_info['affirm_price'] if single_info['affirm_price'] else 0

        up_down_shelves = single_info['up_down_shelves'] if single_info['up_down_shelves'] else 0
        expiry_date = single_info['expiry_date'] if single_info['expiry_date'] else 0
        proportion = single_info['proportion'] if single_info['proportion'] else 0
        is_child = single_info['is_child'] if single_info['is_child'] else 0
        is_config = single_info['is_config'] if single_info['is_config'] else 0
        unit_id = single_info['unit_id'] if single_info['unit_id'] else 0
        brevity = single_info['brevity'].replace("'", "").replace("\\", "") if single_info['brevity'] else ''

        insert_data = (shop_id, code, name, spec, trademark, units, factory_name, addr, img, trade_price, retail_price,
                 status_id, updateAt, repertory, is_standard_barcode, affirm_price, up_down_shelves, expiry_date,
                 proportion, is_child, is_config, unit_id, brevity)
        insert_list.append(insert_data)

        sql = "REPLACE INTO `shopdata`(shop_id, code, name, spec, trademark, units, " \
              "factory_name, addr, img, trade_price, retail_price, status_id, " \
              "updateAt, repertory, is_standard_barcode, affirm_price, up_down_shelves, expiry_date, " \
              "proportion, is_child, is_config, unit_id, brevity) VALUES(" \
              "'%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', %d, " \
              "'%s', %d, %d, %d, %d, %d, %d, %d, %d, %d, '%s')"

        print_sql = "REPLACE INTO `shopdata`(shop_id, code, name, spec, trademark, units, " \
              "factory_name, addr, img, trade_price, retail_price, status_id, " \
              "updateAt, repertory, is_standard_barcode, affirm_price, up_down_shelves, expiry_date, " \
              "proportion, is_child, is_config, unit_id, brevity) VALUES(" \
              "'%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', %d, " \
              "'%s', %d, %d, %d, %d, %d, %d, %d, %d, %d, '%s')" % (shop_id, code, name, spec, trademark, units, factory_name, addr, img, trade_price, retail_price,
                 status_id, updateAt, repertory, is_standard_barcode, affirm_price, up_down_shelves, expiry_date,
                 proportion, is_child, is_config, unit_id, brevity)
        # print print_sql
        # cursor_dw.executemany(sql, insert_list)
        cursor_dw.execute(print_sql)
    conn_dw.commit()



def query_shopdata():
    sql = "SELECT shop_id, code, name, spec, trademark, units, factory_name, " \
          "addr, img, trade_price, retail_price, status_id, updateAt, " \
          "repertory, is_standard_barcode, affirm_price, up_down_shelves, " \
          "expiry_date, proportion, is_child, is_config, unit_id, brevity " \
          "FROM sys_shopdata WHERE shop_id in (3,5,7,14,21,28,29,30,31,32,35,58,61,66,71,85,110,111,113,115,119,128,132,137,143,144,151,174,181,183,189,192,198,199,204,205,206,208,209,211,212,213,214,215,229,230,236,237,241,242,243,244,245,246,247,248,251,252,262,263,264,265,266,275,278,282,283,284,285,287,289,293,294,295,297,299,300,301,302,303,304,305,306,307,308,311,332,333,334,335,336,337,338,339,340,349,350,351,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,370,371,372,373,374,375,376,377,381,382,383,384,385,386,387,390,391,392,393,395,396,397,399,400,401,402,403,405,409,410,411,413,414,415,416,417,418,419,420,421,422)"
    cursor_flask.execute(sql)
    result = cursor_flask.fetchall()

    all_shopdatas = list()
    count = 0
    for r in result:
        count += 1
        single_info = dict()

        single_info['shop_id'] = r[0]
        single_info['code'] = r[1]
        single_info['name'] = r[2]
        single_info['spec'] = r[3]
        single_info['trademark'] = r[4]
        single_info['units'] = r[5]
        single_info['factory_name'] = r[6]
        single_info['addr'] = r[7]
        single_info['img'] = r[8]
        single_info['trade_price'] = r[9]
        single_info['retail_price'] = r[10]
        single_info['status_id'] = r[11]
        single_info['updateAt'] = r[12]
        single_info['repertory'] = r[13]
        single_info['is_standard_barcode'] = r[14]
        single_info['affirm_price'] = r[15]

        single_info['up_down_shelves'] = r[16]
        single_info['expiry_date'] = r[17]
        single_info['proportion'] = r[18]
        single_info['is_child'] = r[19]
        single_info['is_config'] = r[20]
        single_info['unit_id'] = r[21]
        single_info['brevity'] = r[22]

        all_shopdatas.append(single_info)

        if len(all_shopdatas) == 1000:
            insert_shopdata_dw(all_shopdatas)
            all_shopdatas = list()
            print '插入1000行数据, 总: %d' % count
    print "All data insert done."


if __name__ == '__main__':
    query_shopdata()
