# coding:utf8
import requests

def request_post(url, data):
    headers = {'Content-Type': 'application/json', 'apikey': '43aae2d0-625e-11e7-901c-a1891b15059c'}
    result = requests.post(url=url, data=data, headers=headers)
    return result.json()


def request_post_csv_barcode_only(url, data):
    u'''
    导条码专用！！！
    '''
    headers = {'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;',
               'apikey': '43aae2d0-625e-11e7-901c-a1891b15059c'}
    result = requests.post(url=url, data=data, headers=headers)
    return result.json()


def request_get(url):
    headers = {'Content-Type': 'application/json', 'apikey': '43aae2d0-625e-11e7-901c-a1891b15059c'}
    result = requests.get(url=url, headers=headers)
    return result.json()


# 单条获取商品信息 by showapi
def get_product_by_barcode_from_showapi(barcode):
    code = str(barcode)
    if code.isdigit():
        url = 'http://saas.odoo-stagin.esmart365.com:3000/stage/showapi/' + code + ''
        return request_get(url)
    else:
        return {'result': 1}


# 获取单个商品信息 by chinatrace 单条
def get_product_by_barcode_from_chinatrace(barcode):
    code = str(barcode)
    if code.isdigit():
        url = 'http://saas.odoo-stagin.esmart365.com:3000/stage/chinatrace/' + code + ''
        return request_get(url)
    else:
        return {'result': 1}


print get_product_by_barcode_from_showapi('6902088718003')
print get_product_by_barcode_from_chinatrace('6902088718003')


