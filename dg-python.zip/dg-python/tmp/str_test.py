# coding:utf8

print '2017-01-01 11:11:11' > '2017-01-01 11:11:12'

print "'asdasd'adw\\asdwadw".replace("\\", "")