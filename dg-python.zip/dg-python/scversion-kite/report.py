#! /usr/bin/python
# coding:utf8


"""
1. 昨天-按城市分组有心跳包的机器量 并按大小排序
2. 截止到当前全部时间范围内 按城市分组有心跳包的机器量 并按大小排序
3. 当前管理的机器总数量
4. 运行我们程序的机器数量(如太多按前20过滤)
5. 昨天范围内, 运行我们程序的机器上线量, 按城市分组
6. 截止到当前 运行我们程序的机器上线量 按城市分组
"""

import MySQLdb
import psycopg2
import datetime
import sys
import xmlrpc_tool as xt
import json

reload(sys)
sys.setdefaultencoding('utf8')


def send_mail(SUBJECT, message, TO):
    import smtplib
    from email.mime.multipart import MIMEMultipart  # 导入MIMEMultipart类
    from email.mime.text import MIMEText  # 导入MIMEText类

    # TO.append('javacaoyu@163.com')
    HOST = "smtp.exmail.qq.com"  # 定义smtp主机
    # TO = "caoyu03@sinoiov.com;javacaoyu@163.com"    # 定义邮件收件人
    FROM = "no.reply@esmart365.com"  # 定义邮件发件人

    msg = MIMEMultipart('related')  # 创建MIMEMultipart对象，采用related定义内嵌资源的邮件体
    msgtext = MIMEText(message, "html", "utf-8")  # <img>标签的src属性是通过Content-ID来引用的

    msg.attach(msgtext)  # MIMEMultipart对象附加MIMEText的内容
    msg['Subject'] = SUBJECT  # 邮件主题
    msg['From'] = FROM  # 邮件发件人,邮件头部可见
    msg['To'] = ','.join(TO)
    try:
        server = smtplib.SMTP()  # 创建一个SMTP()对象
        server.connect(HOST, "25")  # 通过connect方法连接smtp主机
        # server.starttls()    # 启动安全传输模式
        server.login("no.reply@esmart365.com", "dF7afHrQChf2mk4A")  # 邮箱账号登录校验
        server.sendmail(FROM, TO, msg.as_string())  # 邮件发送
        server.quit()  # 断开smtp连接
        for to in TO:
            print str(datetime.datetime.now()) + ("邮件发送成功！" + to)
    except Exception, e:
        print str(datetime.datetime.now()) + ("邮件发送失败：" + str(e) + "  收件人为: " + str(TO))

conn_mysql = MySQLdb.connect(
    host='scversion.cafnhvr7qay7.rds.cn-north-1.amazonaws.com.cn',
    port=3306,
    user='scversion',
    passwd='Passw0rd',
    db='db_scversion',
    charset='utf8'
)

conn_psql = psycopg2.connect(
    database="portal.hft-pro.esmart365.com",
    user="hft",
    password="Treu23dcl0OepdIe21Q",
    host="pro-postgresql.cafnhvr7qay7.rds.cn-north-1.amazonaws.com.cn",
    port="5432"
    # charset = 'utf8'
)


# cursor_mysql = conn_mysql.cursor()
# cursor_psql = conn_psql.cursor()

message = '<h2><font color="red">说明：此邮件检测风筝系统内的一些指标，程序执行时间：' + str(datetime.datetime.now()) + '</font></h2><br><br><br>'


def getYesterday():
    today = datetime.date.today()
    oneday = datetime.timedelta(days=1)
    yesterday = today - oneday
    return yesterday


def getToday():
    today = datetime.date.today()
    return today


def yesterday_heart_group_by_city():
    """
    昨日有发送心跳包的机器按城市分布
    """
    msg = '<h3>昨日有发送心跳包的机器信息按城市分布</h3><br>'
    msg = msg + '<table border="1" cellspacing="0" cellpadding="0" ><tr class="firstRow"><td width="119" valign="top"><font color="blue">省  份</font></td><td width="119" valign="top"><font color="blue">城  市</font></td><td width="119" valign="top"><font color="blue">机器数量</font></td><td width="119" valign="top"><font color="blue">昨日/平均开机时间(每机器)(分钟)</font></td><td width="119" valign="top"><font color="blue">昨日/总开机时间(全部机器, 单位分钟)</font></td></tr>'
    cursor = conn_mysql.cursor()
    yesterday = str(getYesterday())
    today = str(getToday())
    sql = "select city, region, count(*) as count from (select city, region, count(*) from (select * from MsgRecord where city!='' and inTime>'" + \
          yesterday + "' and inTime<'" + today + "') as sub1 group by cpuID, city) as sub2 group by city order by count desc;"
    cursor.execute(sql)
    result = cursor.fetchall()

    sql = "select region, city, count(*) as count from (select * from MsgRecord where city!='' and inTime>'" + yesterday + "' and " \
        "inTime<'" + today + "' group by inTime, IP) as sub1 group by city order by count desc"
    cursor.execute(sql)
    result2 = cursor.fetchall()

    all_city_machine_number = 0
    for r in result:
        city = str(r[0])
        region = str(r[1])
        number = r[2]
        total_time = '未知'
        avg_time = '未知'

        if city == '':
            city = '未知城市'
        for r2 in result2:
            city2, minute = str(r2[1]), (r2[2] + 1) * 10
            if city2 == city:
                total_time = str(minute)
                avg_time = str((minute / number))
                break

        msg = msg + '<tr><td>' + region + '</td><td>' + city + '</td><td>' + str(number) + '</td><td>' + avg_time + '</td><td>' + total_time + '</td></tr>'
        all_city_machine_number += number
    msg = msg + '</table><br>'
    msg += '<table border="1" cellspacing="0" cellpadding="0" ><tr class="firstRow"><td width="119" valign="top"><font color="blue">总开机机器数量</font></td></tr>'
    msg += '<tr><td>'+str(all_city_machine_number)+'</td></tr>'
    msg = msg + '</table><br><br><br>'
    return msg


def all_time_heart_group_by_city():
    """
    全部时间范围内有发送心跳包的机器按城市分布
    """
    msg = '<h3>截止到程序执行时间, 全部时间范围内有发送心跳包的机器信息按城市分布</h3><br>'
    msg = msg + '<table border="1" cellspacing="0" cellpadding="0" ><tr class="firstRow"><td width="119" valign="top"><font color="blue">省  份</font></td><td width="119" valign="top"><font color="blue">城  市</font></td><td width="119" valign="top"><font color="blue">机器数量</font></td><td width="119" valign="top"><font color="blue">全部时间/平均开机时间(每机器)(分钟)</font></td><td width="119" valign="top"><font color="blue">全部时间/总开机时间(全部机器, 单位分钟)</font></td></tr>'
    cursor = conn_mysql.cursor()
    yesterday = str(getYesterday())
    today = str(getToday())
    sql = "select city, region, count(*) as count from (select city, region, count(*) from (select * from MsgRecord where city!='') as sub1 group by cpuID, city) as sub2 group by city order by count desc"
    cursor.execute(sql)
    result = cursor.fetchall()

    sql = "select region, city, count(*) as count from (select * from MsgRecord where city!='' group by inTime, IP) as sub group by city order by count desc"
    cursor.execute(sql)
    result2 = cursor.fetchall()

    for r in result:
        city = str(r[0])
        region = str(r[1])
        number = r[2]
        total_time = '未知'
        avg_time = '未知'

        if city == '':
            city = '未知城市'
        for r2 in result2:
            city2, minute = str(r2[1]), (r2[2] + 1) * 10
            if city2 == city:
                total_time = str(minute)
                avg_time = str((minute / number))
                break

        msg = msg + '<tr><td>' + region + '</td><td>' + city + '</td><td>' + str(number) + '</td><td>' + avg_time + '</td><td>' + total_time + '</td></tr>'

    msg = msg + '</table><br><br><br>'
    return msg


def all_machine_count():
    """
    截止到程序执行时间, 管理的机器数量
    :return: 机器数量
    """
    msg = '<h3>截止到程序执行时间, 管理的机器数量</h3><br>'
    msg = msg + '<table border="1" cellspacing="0" cellpadding="0" ><tr class="firstRow"><td width="119" valign="top"><font color="blue">机器数量</font></td></tr>'
    cursor = conn_mysql.cursor()
    sql = 'select count(*) from (select cpuID, count(*) from MsgRecord group by cpuID) as sub'
    cursor.execute(sql)
    result = cursor.fetchone()
    all_count = str(result[0])
    msg = msg + '<tr><td>' + all_count + '</td></tr>'
    msg = msg + '</table><br><br><br>'
    return msg


def all_city_machine_avg_running_time_yesterday():
    """
    昨日所有城市开机机器的平均开机时间
    """
    msg = '<h3>昨日上线机器按城市划分总开机时间</h3><br>'
    msg = msg + '<table border="1" cellspacing="0" cellpadding="0" ><tr class="firstRow"><td width="119" valign="top"><font color="blue">省  份</font></td><td width="119" valign="top"><font color="blue">城  市</font></td><td width="119" valign="top"><font color="blue">昨日本城市开机时间(分钟)</font></td></tr>'
    cursor = conn_mysql.cursor()
    yesterday = str(getYesterday())
    today = str(getToday())
    sql = "select region, city, count(*) as count from (select * from MsgRecord where city!='' and inTime>'" + yesterday + "' and " \
          "inTime<'" + today + "' group by inTime, IP) as sub1 group by city order by count desc"
    cursor.execute(sql)
    result = cursor.fetchall()
    for r in result:
        region, city, minute = str(r[0]), str(r[1]), str((r[2] + 1) * 10)
        msg = msg + '<tr><td>' + region + '</td><td>' + city + '</td><td>' + minute + '</td></tr>'

    msg = msg + '</table><br><br><br>'
    return msg


def use_cpuID_found_hft_machine(cpuid):
    cpuids = []
    cpuid = str(cpuid)
    cursor = conn_psql.cursor()
    sql = "select mac from shop_pos_mac_sn where cpu_id='"+cpuid+"'"
    cursor.execute(sql)
    mac_result = cursor.fetchone()
    if mac_result:
        mac = str(mac_result[0])
        sql = "select id from shop_pos_machine WHERE mac='"+mac+"'"
        cursor.execute(sql)
        result = cursor.fetchall()
        if result:
            return True

    return False


def run_hft_count():
    """
    先找到所有运行我们程序的机器的CPUID
    """
    true_cpuids = []
    cursor = conn_mysql.cursor()
    sql = 'select cpuID from MsgRecord GROUP BY cpuID'
    cursor.execute(sql)
    result = cursor.fetchall()
    for r in result:
        cpuid = str(r[0])
        cpuid = cpuid.upper()
        if use_cpuID_found_hft_machine(cpuid):
            true_cpuids.append(cpuid)

    return true_cpuids


def run_hft_machine_info():
    """
    运行我们机器的CPUID对应的信息
    :return:
    """
    msg = '<h3>截止到程序执行时间, 运行惠付通软件的机器列表</h3><br>'
    msg = msg + '<table border="1" cellspacing="0" cellpadding="0" ><tr class="firstRow">' \
                '<td width="119" valign="top"><font color="blue">省  份</font></td>' \
                '<td width="119" valign="top"><font color="blue">城  市</font></td>' \
                '<td width="119" valign="top"><font color="blue">cpuid</font></td>' \
                '<td width="119" valign="top"><font color="blue">mac</font></td>' \
                '<td width="119" valign="top"><font color="blue">店铺名称</font></td>' \
                '<td width="119" valign="top"><font color="blue">店铺ID</font></td>' \
                '<td width="119" valign="top"><font color="blue">软件版本</font></td>' \
                '<td width="119" valign="top"><font color="blue">店铺创建时间</font></td>' \
                '<td width="119" valign="top"><font color="blue">心跳数量</font></td>' \
                '<td width="119" valign="top"><font color="blue">IP</font></td></tr>'
    cpuids = run_hft_count()
    print len(cpuids), '台机器运行我们的程序'
    # for cpuid in cpuids:
    #     cursor = conn_mysql.cursor()
    #     sql = "select region, city from MsgRecord where city!='' and cpuID='"+cpuid+"' GROUP BY cpuID"
    #     cursor.execute(sql)
    #     result = cursor.fetchall()
    #     for r in result:
    #         region = str(r[0])
    #         city = str(r[1])
    #         msg = msg + '<tr><td>' + region + '</td><td>' + city + '</td><td><a href="https://portal.hft-pro.esmart365.com/web/kiterunner/getsumminfo?cpuid=' + cpuid + '">' + cpuid + '</a></td></tr>'


    cpuids_str = ','.join(cpuids)

    result = xt.call_execute('kite.summsgrecord', 'get_infos', [], cpuids_str)
    infos = json.loads(result)
    print len(infos['data']), '台机器运行我们的程序222'
    for info in infos['data']:
        cpuid = info['cpuid'] if 'cpuid' in info.keys() else False
        if not cpuid:
            continue
        store_id, ip, mac, city, swver, shopname, \
        region, systemver, shopcreatetime, count = info['shopid'], info['ip'], info['mac'], info['city'], info['swver'], \
                                                   info['shopname'], \
                                                   info['region'], info['systemver'], info['shopcreatetime'], info[
                                                       'count']
        msg = msg + '<tr><td>' + region + '</td>' \
                    '<td>' + city + '</td>' \
                    '<td>' + cpuid + '</td>' \
                    '<td>' + mac + '</td>' \
                    '<td>' + shopname + '</td>' \
                    '<td>' + str(store_id) + '</td>' \
                    '<td>' + str(swver) + '</td>' \
                    '<td>' + shopcreatetime + '</td>' \
                    '<td>' + str(count) + '</td>' \
                    '<td>' + ip + '</td></tr>'
    msg = msg + '</table><br><br><br>'
    # msg = msg + '<a href="https://portal.hft-pro.esmart365.com/web/kiterunner/getsumminfo?cpuid='+cpuids_str+'"><h1>点击这里, 查看上述全部CPUID的详细情况</h1></a><br><br>'

    return msg

if __name__ == '__main__':
    # run_hft_count()
    try:
        result = '' + yesterday_heart_group_by_city() + all_time_heart_group_by_city() + run_hft_machine_info() + \
                  all_city_machine_avg_running_time_yesterday() + all_machine_count()
    except Exception, e:
        result = '' + yesterday_heart_group_by_city() + all_time_heart_group_by_city() + run_hft_machine_info() + \
                  all_city_machine_avg_running_time_yesterday() + all_machine_count()

    message = message + result
    message = message + '<br><br><br><br><br>'
    #
    #

    TO = ['yu.cao@esmart365.com']
    TO.append('qiang.sun@esmart365.com')
    TO.append('zhilin.zhang@esmart365.com')
    TO.append('vicky.liu@esmart365.com')
    send_mail('风筝系统每日报告', message, TO)

# print message
