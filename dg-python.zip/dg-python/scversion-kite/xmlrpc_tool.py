#! /usr/bin/python
# coding:utf8

import xmlrpclib

__author__ = 'CaoYu'

portal_url = 'https://portal.hft-pro.esmart365.com'
portal_db = 'portal.hft-pro.esmart365.com'
admin_username = 'admin'
admin_password = 'Qeuts23hfu3906AejseiGOOD'

common = xmlrpclib.ServerProxy('{}/xmlrpc/2/common'.format(portal_url))
admin_uid = common.authenticate(portal_db, admin_username, admin_password, {})
models = xmlrpclib.ServerProxy('{}/xmlrpc/2/object'.format(portal_url))


def call_execute(model_name, func, args, kwargs):
    result = models.execute(portal_db, admin_uid, admin_password, model_name, func, args, kwargs)
    return result


def call_execute_kw(model_name, func, kwargs, args=[]):
    result = models.execute_kw(portal_db, admin_uid, admin_password, model_name, func, args, kwargs)
    return result
