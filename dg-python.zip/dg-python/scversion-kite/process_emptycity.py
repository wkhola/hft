#! /usr/bin/python
# coding:utf8

import MySQLdb
import sys
import requests
import re
import datetime
"""
处理风筝系统MsgRecord表中太多city和region字段是空值的问题
"""
__author__ = 'CaoYu'

reload(sys)
sys.setdefaultencoding('utf8')

reip = re.compile(r'(?<![\.\d])(?:\d{1,3}\.){3}\d{1,3}(?![\.\d])')

conn = MySQLdb.connect(
    host='scversion.cafnhvr7qay7.rds.cn-north-1.amazonaws.com.cn',
    port=3306,
    user='scversion',
    passwd='Passw0rd',
    db='db_scversion',
    charset='utf8'
)


def requests_get(url, encoding):
    headers = {'Content-Type': 'application/json'}
    # headers = {'Content-Type': 'application/json', 'token': 'b571171c024d8400633c75561a926089'}
    result = requests.get(url=url, headers=headers)
    result.encoding = encoding
    return result.text


def extract_province_city(result):
    start_index = result.find('本站数据')
    end_index = result.find('</li>', start_index)
    area = result[start_index: end_index].split('：')[1].split('  ')[0].split(' ')[0]
    is_sheng = area.find('省')
    if not is_sheng == -1:
        region = area.split('省')[0] + '省'
        city = area.split('省')[1]
        return region, city

    is_qu = area.find('自治区')
    if not is_qu == -1:
        region = area.split('自治区')[0] + '自治区'
        city = area.split('自治区')[1]
        return region, city

    is_zhixiashi = area.count('市')
    if is_zhixiashi > 1:
        region = area.split('市')[0] + '市'
        city = area.split('市')[1] + '市'
        return region, city

    is_xingzhengqu = area.find('行政区')
    if not is_xingzhengqu == -1:
        region = area.split('行政区')[0] + '行政区'
        city = region.replace('特别', '').replace('行政区', '') + '市'
        return region, city

    is_single_city = area.count('市')
    if is_single_city == 1:
        region = area.split('市')[0] + '市'
        city = area.split('市')[0] + '市'
        return region, city

    return '', ''


def process():
    """
    处理
    :return:
    """
    cursor = conn.cursor()
    sql = "SELECT id, IP FROM MsgRecord WHERE city='' group by IP"
    cursor.execute(sql)
    result = cursor.fetchall()

    count = 0
    for r in result:
        rid, ip = r[0], r[1]
        if ip:
            sql = "SELECT region, city FROM MsgRecord WHERE IP='" + ip + \
                  "' AND city!='' ORDER BY inTime DESC LIMIT 1"
            cursor.execute(sql)
            result_non_empty_city = cursor.fetchone()
            if result_non_empty_city:
                region, city = result_non_empty_city[0], result_non_empty_city[1]
                sql = "UPDATE MsgRecord SET region='" + region + "', city='" + city + \
                      "' WHERE city='' and IP='" + ip + "'"
                cursor.execute(sql)
                count += 1
                print '处理一个IP, 共处理: ' + str(count) + ', 被设置的IP是' + ip + \
                      ", 要设置省份: " + region + ", 城市:" + city + ", " + str(datetime.datetime.now())
            else:
                is_ip = reip.findall(ip)
                if is_ip:
                    url = 'http://www.ip138.com/ips138.asp?ip=%s&action=2' % (ip)
                    result = requests_get(url, 'gbk')

                    try:
                        region, city = extract_province_city(result)
                    except Exception, e:
                        print '提取出错, ip: ' + ip + ", " + str(datetime.datetime.now())
                        break

                    sql = "UPDATE MsgRecord SET region='" + region + "', city='" + city + \
                          "' WHERE city='' and IP='" + ip + "'"
                    cursor.execute(sql)
                    count += 1
                    print '处理一个IP, 共处理: ' + str(count) + ', 被设置的IP是' + ip + \
                          ", 要设置省份: " + region + ", 城市:" + city + ", " + str(datetime.datetime.now()) + ', (通过IP138查询出地区)'
                else:
                    print 'ip不是标准IP, ip是: ' + ip + ', ' + str(datetime.datetime.now())

        if count % 1000 == 0:
            conn.commit()
            print '处理1000条, 当前: ' + str(count) + ', ' + str(datetime.datetime.now())

    cursor.close()


if __name__ == '__main__':
    process()
    conn.close()
