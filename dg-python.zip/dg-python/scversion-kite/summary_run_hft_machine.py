#! /usr/bin/python
# coding:utf8

import MySQLdb
import json
import report
import xmlrpc_tool
# import sys
# reload(sys)
# sys.setdefaultencoding('utf8')

__author__ = 'CaoYu'

"""
查询风筝系统中, 运行HFT程序的机器信息, 并写入数据库中
"""

conn = MySQLdb.connect(
    # -- azure mysql
    host='hftdw.mysqldb.chinacloudapi.cn',
    user='hftdw%hft',
    passwd='Qejwijfj@jidijsei#2i3j!@#^^^66',
    db='scversion',
    # -- aws mysql
    # host='scversion.cafnhvr7qay7.rds.cn-north-1.amazonaws.com.cn',
    # user='scversion',
    # passwd='Passw0rd',
    # db='db_scversion',
    port=3306,
    charset='utf8'
)


def get_cpuids_infos():
    cpuids = report.run_hft_count()
    cpuids = ','.join(cpuids)
    result = xmlrpc_tool.call_execute('kite.summsgrecord', 'get_infos', [], cpuids)
    print result
    return result


def insert_db(infos):
    """
    将查到的CPUIDS查询出信息, 封装后写入mysql, RunHFTMachine表中
    :param infos:
    :return:
    """
    cursor = conn.cursor()
    infos = json.loads(infos)
    for info in infos['data']:
        cpuid = info['cpuid'] if 'cpuid' in info.keys() else False
        if not cpuid:
            continue

        store_id, ip, mac, city, swver, shopname, \
        region, systemver, shopcreatetime, count = info['shopid'], info['ip'], info['mac'], info['city'], info['swver'], info['shopname'], \
                                                   info['region'], info['systemver'], info['shopcreatetime'], info['count']
        result = insert_sql = ("INSERT INTO RunHFTMachine(cpuID, region, city, mac, store_name, store_id, store_create_time, " \
                 "last_ip, heart_count, soft_version, sys_version) VALUES('%s', '%s', '%s', '%s', '%s', %d, '%s', '%s', %d, '%s', '%s')" \
                 " ON DUPLICATE KEY UPDATE region=VALUES(region), city=VALUES(city), mac=VALUES(mac), store_name=VALUES(store_name), " \
                 "store_create_time=VALUES(store_create_time), last_ip=VALUES(last_ip), heart_count=VALUES(heart_count), " \
                 "soft_version=VALUES(soft_version), sys_version=VALUES(sys_version)" % (cpuid, region, city, mac, shopname, store_id, shopcreatetime, ip, count, swver, systemver))
        cursor.execute(insert_sql)
        print 'insert one data.', result
    conn.commit()
    conn.close()


if __name__ == '__main__':
    infos = get_cpuids_infos()
    print insert_db(infos=infos)
