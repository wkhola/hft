#! /usr/bin/python
# coding:utf8

import requests
import re
import sys
__author__ = 'CaoYu'
reload(sys)
sys.setdefaultencoding('utf8')
reip = re.compile(r'(?<![\.\d])(?:\d{1,3}\.){3}\d{1,3}(?![\.\d])')



def requests_get(url, encoding):
    headers = {'Content-Type': 'application/json'}
    # headers = {'Content-Type': 'application/json', 'token': 'b571171c024d8400633c75561a926089'}
    result = requests.get(url=url, headers=headers)
    result.encoding = encoding
    return result.text


def extract_province_city(result):
    start_index = result.find('本站数据')
    end_index = result.find('</li>', start_index)
    area = result[start_index: end_index].split('：')[1].split('  ')[0].split(' ')[0]
    is_sheng = area.find('省')
    if not is_sheng == -1:
        region = area.split('省')[0] + '省'
        city = area.split('省')[1]
        return region, city

    is_qu = area.find('自治区')
    if not is_qu == -1:
        region = area.split('自治区')[0] + '自治区'
        city = area.split('自治区')[1]
        return region, city

    is_zhixiashi = area.count('市')
    if is_zhixiashi > 1:
        region = area.split('市')[0] + '市'
        city = area.split('市')[1] + '市'
        return region, city

    is_xingzhengqu = area.find('行政区')
    if not is_xingzhengqu == -1:
        region = area.split('行政区')[0] + '行政区'
        city = region.replace('特别', '').replace('行政区', '') + '市'
        return region, city

    is_single_city = area.count('市')
    if is_single_city == 1:
        region = area.split('市')[0] + '市'
        city = area.split('市')[0] + '市'
        return region, city

    return '', ''

ip = '58.254.64.3'
url = 'http://www.ip138.com/ips138.asp?ip=%s&action=2' % (ip)
result = requests_get(url, 'gbk')
region, city = extract_province_city(result)
print region, city