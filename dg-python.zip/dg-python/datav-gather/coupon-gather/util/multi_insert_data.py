#!/usr/bin/python
# coding:utf-8
from logger import Logger

logger = Logger('multi_insert_data.py')


def multi_insert_data(data, decorator, conn, cursor, table, columns=None, chunk_size=100):
    """
    文件批量导入数据库
    :param columns: list, default None
    :param data: Pandas DataFrame
    :param decorator: 导入格式 如 :code_decorator
    :param conn:
    :param cursor:
    :param table: 导入目标table
    :param chunk_size: 单次批量导入数据条数
    :return:
    """

    """
    code_decorator = lambda x: "(" + x.split(',')[0].strip() + ', ' + "'" + \
                               x.split(',')[1] + "'" + ', ' \
                               + "'" + x.split(',')[2] + "'" + ', ' \
                               + "'" + x.split(',')[3] + "'" + ")"
    """
    all_rows = [decorator(row) for row in data.fillna("").values]
    if not columns:
        sql = 'REPLACE INTO ' + table + ' VALUES '
    else:
        sql = 'REPLACE INTO ' + table + "(" + ','.join(columns) + ")" + ' VALUES '

    n, k = len(all_rows) // chunk_size, len(all_rows) % chunk_size

    for i in range(0, n):
        multi_rows = ', \n'.join(all_rows[i * chunk_size:(i + 1) * chunk_size])
        try:
            cursor.execute(sql + multi_rows)
            conn.commit()
            logger.info("采集数据为：" + sql + '\n' + multi_rows)
        except Exception as e:
            logger.error(e)
    if k:
        multi_rows = ', \n'.join(all_rows[-k:])
        try:
            cursor.execute(sql + multi_rows)
            conn.commit()
            logger.info("采集数据为：" + sql + '\n' + multi_rows)
        except Exception as e:
            logger.error(e)
    return None
