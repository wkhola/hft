# coding:utf8
import sys
import traceback

import pandas as pd
from logger import Logger
import requests

from common import common
from util.multi_insert_data import multi_insert_data

__author__ = 'WuKai'
default_encoding = 'utf-8'
if sys.getdefaultencoding() != default_encoding:
    reload(sys)
    sys.setdefaultencoding(default_encoding)
_logger = Logger("service.py")


class MyQuery():
    def __init__(self):
        self.conn = common.conn
        self.con_rds = common.conn_rds

    def query_member_login_log(self):
        """
        查询用户登陆数据
        :return: return data
        """
        last_update_id = common.get_last_update_member_login_log()
        data = pd.DataFrame()
        sql = "select member_login_log_id, member_id, login_time, client_ip, remark, lng, lat from member_login_log " \
              "where member_login_log_id > {}".format(last_update_id)
        try:
            data = pd.read_sql(sql, self.conn)
        except Exception as e:
            _logger.error("member表数据查询失败，信息为：")
            _logger.error(traceback.format_exc(e))
        last_update = data.member_login_log_id.max()
        count = int(data.member_login_log_id.count())

        _logger.info("查询member_login_log_id信息成功, 从ID: " + last_update_id +
                     "开始, 查询出: " + str(count) + "条信息.")
        return data, last_update

    def insert_member_login_log_dw(self, data, last_update):
        """
        数据插入进 member_login_log 数据库
        :param data:
        :param last_update:
        :return:
        """
        cursor = self.con_rds.cursor()
        _logger.info("开始插入数据进member_login_log")

        columns = ['member_login_log_id', 'member_id', 'login_time', 'client_ip', 'gps_lat', 'gps_lon',
                   'province', 'city', 'district', 'remark']
        def fmt_func(x):
            key = 'J4DBZ-SW4KQ-AOI55-GOLON-4GMD7-F2BKR'
            gps_lat = str(x[5]).strip()
            gps_lon = str(x[6]).strip()
            a = requests.get(
                "https://apis.map.qq.com/ws/geocoder/v1/?location={},{}&key={}".format(gps_lat, gps_lon, key))
            content = a.json()
            province = ""
            city = ""
            district = ""
            try:
                province = content['result']['ad_info']['province'] if content['result']['ad_info']['province'] else ""
                city = content['result']['ad_info']['city'] if content['result']['ad_info']['city'] else ""
                district = content['result']['ad_info']['district'] if content['result']['ad_info']['district'] else ""
            except Exception as e:
                _logger.error("输入参数有误，正确格式为：维度, 经度")
                _logger.error(traceback.format_exc(e))
            # return {"province": province, "city": city, "district": district}
            print province, city, district
            # str(x[7]), str(x[8]), str(x[9]) =
            print str(x[6]).replace("'", '').strip()
            print type(x[4]), x[0], x
            print "(" + str(x[0]).strip() + ', ' \
                   + "'" + str(x[1]).replace("'", '').strip() + "'" + ', ' \
                   + "'" + str(x[2]).replace("'", '').strip() + "'" + ', ' \
                   + "'" + str(x[3]).replace("'", '').strip() + "'" + ', ' \
                   + str(x[5]).strip() + ', ' \
                   + str(x[6]).strip() + ',' \
                   + "'" + province + "'" + ', ' \
                   + "'" + city + "'" + ', ' \
                   + "'" + district + "'" + ', ' \
                   + "'" + str(x[4]).replace("'", '').strip() + "'" + ')'

        try:
            multi_insert_data(data, decorator=fmt_func, conn=self.con_rds, cursor=cursor,
                              columns=columns, table='member_login_log', chunk_size=10000)
            if str(last_update) != 'nan' and str(last_update).isdigit():
                common.write_last_update_member_login_log(last_update)
                _logger.info('member_login_log 数据导入数据仓库成功,一共追加{}条数据进DW'.format(data.iloc[:, 0].size))
        except Exception as e:
            _logger.error("------member_login_log 数据导入失败，提示信息为:")
            _logger.error(traceback.format_exc(e))

    def query_member(self):
        """
        查询会员数据
        :return: return data
        """
        data = pd.DataFrame()
        last_member_id = common.get_last_update_member()
        sql = "select member_id, full_name, gender, province, city, area, address, mobile, email, register_time, " \
              " avatar, password, valid, birthday, marriage, remark, is_active, open_id, level, promo_code, " \
              "origin_code from member where member_id > {}".format(last_member_id)
        try:
            data = pd.read_sql(sql, self.conn)
        except Exception as e:
            _logger.error("member表数据查询失败，信息为：")
            _logger.error(traceback.format_exc(e))
        last_update = data.member_id.max()
        count = int(data.member_id.count())
        _logger.info("查询member信息成功, 从ID: " + last_member_id + "开始, 查询出: " + str(count) + "条信息.")
        return data, last_update

    def query_coupon_lottery_record(self):
        """
        查询中奖信息
        :return: return data
        """
        last_lottery_record_id = common.get_last_update_lottery_record_id()
        sql = "select lottery_record_id, coupon_code, member_id, create_time, openid, phone, lottery_set_id, " \
              "coupon_rule_id from coupon_Lottery_record where lottery_record_id > {}".format(last_lottery_record_id)
        data = pd.DataFrame()
        try:
            data = pd.read_sql(sql, self.conn)
        except Exception as e:
            _logger.error("coupon_Lottery_record表数据查询失败，信息为：")
            _logger.error(traceback.format_exc(e))
        last_update = data.lottery_record_id.max()
        count = int(data.lottery_record_id.count())
        _logger.info("查询coupon_Lottery_record信息成功, 从ID: " + last_lottery_record_id + "开始, 查询出: "
                     + str(count) + "条信息.")
        return data, last_update

    def insert_coupon_lottery_record_dw(self, data, last_update):
        """
        数据插入进 member_login_log 数据库
        :param data:
        :param last_update:
        :return:
        """
        cursor = self.con_rds.cursor()
        _logger.info("开始插入数据进coupon_lottery_record")

        columns = ['lottery_record_id', 'coupon_code', 'member_id', 'create_time', 'openid', 'phone', 'lottery_set_id',
                   'coupon_rule_id']

        def fmt_func(x):
            return "(" + str(x[0]).strip() + ', ' \
                   + "'" + str(x[1]).strip() + "'" + ', ' \
                   + "'" + str(x[2]).strip() + "'" + ', ' \
                   + "'" + str(x[3]).strip() + "'" + ', ' \
                   + "'" + str(x[4]).strip() + "'" + ', ' \
                   + "'" + str(x[5]).strip() + "'" + ', ' \
                   + str(x[6]).strip() + ', ' \
                   + str(x[7]).strip() + ')'

        try:
            multi_insert_data(data, decorator=fmt_func, conn=self.con_rds, cursor=cursor,
                              columns=columns, table='coupon_Lottery_record', chunk_size=10000)
            if str(last_update) != 'nan' and str(last_update).isdigit():
                common.write_last_update_coupon_lottery_record_id(last_update)
                _logger.info('coupon_Lottery_record 数据导入数据仓库成功,一共追加{}条数据进DW'
                             .format(data.iloc[:, 0].size))
        except Exception as e:
            _logger.error("------coupon_Lottery_record 数据导入失败，提示信息为:")
            _logger.error(traceback.format_exc(e))

    def insert_member_dw(self, data, last_update):
        """
        数据插入进 member 数据库
        :param data:
        :param last_update:
        :return:
        """
        cursor = self.con_rds.cursor()
        _logger.info("开始插入数据进member")

        columns = ['member_id', 'full_name', 'gender', 'province', 'city', 'area', 'address', 'mobile', 'email',
                   'register_time', 'avatar', 'password', 'valid', 'birthday', 'marriage', 'remark',
                   'is_active', 'open_id', 'level', 'promo_code', 'origin_code']

        def fmt_func(x):
            return "(" + "'" + str(x[0]).strip() + "'" + ', ' \
                   + "'" + str(x[1]).strip().replace("'", "") + "'" + ', ' \
                   + str(x[2]).strip() + ', ' \
                   + str(x[3]).strip() + ', ' \
                   + str(x[4]).strip() + ', ' \
                   + str(x[5]).strip() + ', ' \
                   + "'" + str(x[6]).strip() + "'" + ', ' \
                   + "'" + str(x[7]).strip() + "'" + ', ' \
                   + "'" + str(x[8]).strip() + "'" + ', ' \
                   + "'" + str(x[9]).strip() + "'" + ', ' \
                   + "'" + str(x[10]).strip() + "'" + ', ' \
                   + "'" + str(x[11]).strip() + "'" + ', ' \
                   + str(x[12]).strip() + ', ' \
                   + "'" + str(x[13]).strip() + "'" + ', ' \
                   + str(x[14]).strip() + ', ' \
                   + "'" + str(x[15]).strip() + "'" + ', ' \
                   + str(x[16]).strip() + ', ' \
                   + "'" + str(x[17]).strip() + "'" + ', ' \
                   + str(x[18]).strip() + ', ' \
                   + "'" + str(x[19]).strip() + "'" + ', ' \
                   + "'" + str(x[20]).strip() + "'" + ')'

        try:
            multi_insert_data(data, decorator=fmt_func, conn=self.con_rds, cursor=cursor,
                              columns=columns, table='member', chunk_size=10000)
            if str(last_update) != 'nan' and str(last_update).isdigit():
                common.write_last_update_member(last_update)
                _logger.info('member 数据导入数据仓库成功,一共追加{}条数据进DW'.format(data.iloc[:, 0].size))
        except Exception as e:
            _logger.error("------member 数据导入失败，提示信息为:")
            _logger.error(traceback.format_exc(e))

    def query_activity(self):
        """
        查询活动数据
        :return: return data
        """
        data = pd.DataFrame()
        sql = "select id, name, start_time, end_time, pic_url, position, rate, number_people, `explain`, " \
              "counts, `type` from activity "
        try:
            data = pd.read_sql(sql, self.conn)
        except Exception as e:
            _logger.error("activity表数据查询失败，信息为：")
            _logger.error(traceback.format_exc(e))
        count = int(data[data.id == 4].counts) if int(data[data.id == 4].counts) else 0

        _logger.info("有效抽奖数为: " + str(count))
        return data

    def insert_activity_dw(self, data):
        """
        数据插入进 activity 数据库
        :param data:
        :return:
        """
        cursor = self.con_rds.cursor()
        _logger.info("开始插入数据进activity")

        columns = ['id', 'name', 'start_time', 'end_time', 'pic_url', 'position', 'rate', 'number_people',
                   '`explain`', 'counts', '`type`']

        def fmt_func(x):
            return "(" + str(x[0]).strip() + ', ' \
                   + "'" + str(x[1]).strip() + "'" + ', ' \
                   + "'" + str(x[2]).strip() + "'" + ', ' \
                   + "'" + str(x[3]).strip() + "'" + ', ' \
                   + "'" + str(x[4]).strip() + "'" + ', ' \
                   + "'" + str(x[5]).strip() + "'" + ', ' \
                   + str(x[6]).strip() + ', ' \
                   + str(x[7]).strip() + ', ' \
                   + "'" + str(x[8]).strip() + "'" + ', ' \
                   + str(x[9]).strip() + ', ' \
                   + str(x[10]).strip() + ')'

        try:
            multi_insert_data(data, decorator=fmt_func, conn=self.con_rds, cursor=cursor,
                              columns=columns, table='activity', chunk_size=10000)
            _logger.info('activity 数据导入数据仓库成功,一共追加{}条数据进DW'.format(data.iloc[:, 0].size))
        except Exception as e:
            _logger.error("------activity 数据导入失败，提示信息为:")
            _logger.error(traceback.format_exc(e))

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(MyQuery,
                                  cls).__new__(cls, *args, **kwargs)
        return cls._instance
