# coding:utf8

import pymysql as MySQLdb
import ConfigParser
import string
import os
from logger import Logger
"""
公共组件文件, 包含所有公共方法供使用
"""
__author__ = 'WuKai'

logger = Logger('common.py')

conf = ConfigParser.ConfigParser()
conf.read("./config/config.conf")
last_update_member_login_log_file_path = conf.get('common', 'last_update_member_login_log_file_path')
last_update_member_file_path = conf.get('common', 'last_update_member_file_path')
last_update_lottery_record_id_file_path = conf.get('common', 'last_update_lottery_record_id_file_path')

# Get connection for mysql
conn = MySQLdb.connect(
    host=conf.get('mysql-barcode', 'db_host'),
    port=string.atoi(conf.get('mysql-barcode', 'db_port')),
    user=conf.get('mysql-barcode', 'db_user'),
    passwd=conf.get('mysql-barcode', 'db_password'),
    db=conf.get('mysql-barcode', 'db_db'),
    charset='utf8mb4'
)

conn_rds = MySQLdb.connect(
    host=conf.get('rds-datawarehouse', 'db_host'),
    port=string.atoi(conf.get('rds-datawarehouse', 'db_port')),
    user=conf.get('rds-datawarehouse', 'db_user'),
    password=conf.get('rds-datawarehouse', 'db_password'),
    database=conf.get('rds-datawarehouse', 'db_db'),
    charset='utf8mb4'
)


def close_all_connection():
    """
    Close all db connection
    :return: None
    """
    conn.close()
    conn_rds.close()


def init():
    """
    初始化
    :return:
    """
    if not os.path.exists(last_update_member_login_log_file_path):
        open(last_update_member_login_log_file_path, 'a')
        logger.info("缓存上次查询的缓存文件: " + last_update_member_login_log_file_path + " 不存在, 创建...")

    if not os.path.exists(last_update_member_file_path):
        open(last_update_member_file_path, 'a')
        logger.info("缓存上次查询的缓存文件: " + last_update_member_file_path + " 不存在, 创建...")

    if not os.path.exists(last_update_lottery_record_id_file_path):
        open(last_update_lottery_record_id_file_path, 'a')
        logger.info("缓存上次查询的缓存文件: " + last_update_lottery_record_id_file_path + " 不存在, 创建...")


def get_last_update_member_login_log():
    """
    获得上次查询到的update member_login_log
    :return: 0 第一次, 非第一次返回member_login_log
    """
    last_update = open(last_update_member_login_log_file_path, 'r')
    last_update_barcode = last_update.readline()
    if not last_update_barcode:
        logger.info("查询上次查询的更新时间(member_login_log)方法: 这是第一次查询, 返回为0")
        return '0'
    else:
        logger.info("查询上次查询的更新时间(member_login_log)方法: 从文件中取得last_update为: " + str(last_update_barcode))
        return str(last_update_barcode).strip()


def get_last_update_member():
    """
    获得上次查询到的update member
    :return: 0 第一次, 非第一次返回 member
    """
    last_update = open(last_update_member_file_path, 'r')
    last_update_data = last_update.readline()
    if not last_update_data:
        logger.info("查询上次查询的更新时间(member_login_log)方法: 这是第一次查询, 返回为0")
        return '0'
    else:
        logger.info("查询上次查询的更新时间(member_login_log)方法: 从文件中取得last_update为: " + str(last_update_data))
        return str(last_update_data).strip()


def get_last_update_lottery_record_id():
    """
    获得上次查询到的update last_lottery_record_id
    :return: 0 第一次, 非第一次返回last_lottery_record_id
    """
    last_update = open(last_update_lottery_record_id_file_path, 'r')
    last_update_data = last_update.readline()
    if not last_update_data:
        logger.info("查询上次查询的更新时间(last_update_lottery_record_id)方法: 这是第一次查询, 返回为0")
        return '0'
    else:
        logger.info("查询上次查询的更新时间(last_update_lottery_record_id)方法: 从文件中取得last_update为: " + str(last_update_data))
        return str(last_update_data).strip()


def write_last_update_member_login_log(last_update):
    """
    写上次查询到的last_update barcode到文件中, 每次都清空文件.
    :param last_update:
    :return: None
    """
    logger.info("写last_update(member_login_log)到缓存文件中, 当前last_update为: " +
                str(get_last_update_member_login_log()) + ", 当前写入: " + str(last_update))
    last_update = str(last_update)
    last_update_member_login_log_file_w = open(last_update_member_login_log_file_path, 'w')
    last_update_member_login_log_file_w.write(last_update)


def write_last_update_member(last_update):
    """
    写上次查询到的last_update barcode到文件中, 每次都清空文件.
    :param last_update:
    :return: None
    """
    logger.info("写last_update(member)到缓存文件中, 当前last_update为: " +
                str(get_last_update_member()) + ", 当前写入: " + str(last_update))
    last_update = str(last_update)
    last_update_member_file_w = open(last_update_member_file_path, 'w')
    last_update_member_file_w.write(last_update)


def write_last_update_coupon_lottery_record_id(last_update):
    """
    写上次查询到的last_update barcode到文件中, 每次都清空文件.
    :param last_update:
    :return: None
    """
    logger.info("写last_update(last_update_data)到缓存文件中, 当前last_update为: " +
                str(get_last_update_lottery_record_id()) + ", 当前写入: " + str(last_update))
    last_update = str(last_update)
    last_update_lottery_record_id_file_w = open(last_update_lottery_record_id_file_path, 'w')
    last_update_lottery_record_id_file_w.write(last_update)


init()
