#! /usr/bin/python
# coding:utf8

from logger import Logger
from service import MyQuery

__author__ = 'WuKai'
_logger = Logger('coupon-gather.py')


if __name__ == '__main__':
    _logger.info('----------------------------start-----------------------------------')
    query = MyQuery()
    _logger.info("开始查询出member_login_log信息, 并执行插入操作")
    data, last_update = query.query_member_login_log()
    if str(last_update) != 'nan':
        query.insert_member_login_log_dw(data, last_update)
    else:
        _logger.info("本次查询没有查询出member_login_log信息, 不进行插入操作")

    _logger.info("开始查询出member信息, 并执行插入操作")
    data, last_update = query.query_member()
    if str(last_update) != 'nan':
        query.insert_member_dw(data, last_update)
    else:
        _logger.info("本次查询没有查询出member信息, 不进行插入操作")

    _logger.info("开始查询出coupon_lottery_record信息, 并执行插入操作")
    data, last_update = query.query_coupon_lottery_record()
    if str(last_update) != 'nan':
        query.insert_coupon_lottery_record_dw(data, last_update)
    else:
        _logger.info("本次查询没有查询出coupon_lottery_record信息, 不进行插入操作")

    _logger.info("开始查询出activity信息, 并执行插入操作")
    data = query.query_activity()

    query.insert_activity_dw(data)
    _logger.info('----------------------------e n d-----------------------------------')
