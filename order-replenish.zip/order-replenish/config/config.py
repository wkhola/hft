# coding: utf-8
import configparser
import os


def read_config():
    current_path = os.path.abspath(__file__)
    init = configparser.ConfigParser()
    config_file_path = os.path.join(
        os.path.dirname(current_path), "config.txt")
    init.read(config_file_path)
    return init

config = read_config()
