# -*- coding: utf-8 -*-
import traceback
from copy import deepcopy

from common.send_mq import send2rabbitmq
from source.details import details
from source.order import order_dict_ori, product_dict
from util.logger import Logger
from sqlalchemy import select

logger = Logger('oder_data_add.py')


class OderDataAdd(object):
    @staticmethod
    def send_msg(data):
        try:
            send2rabbitmq(data)
            logger.info('send msg success')
            return True
        except Exception as e:
            logger.error(traceback.format_exc(e))
            return False


def get_all_data_dict(results, dt, connection):
    all_order_dict = dict({})
    all_order_list = []
    for item in results:
        order_dict = deepcopy(order_dict_ori)

        order_dict['order_id'] = item[0]
        order_dict['date'] = item[1].strftime('%Y-%m-%d %H:%M:%S')
        order_dict['day_order_seq'] = item[2]
        order_dict['origin'] = item[3]
        order_dict['store_id'] = item[4]
        order_dict['operator'] = item[5]
        order_dict['member_id'] = item[6]
        order_dict['face_id'] = item[7]
        order_dict['product_count'] = item[8]
        order_dict['payment']['total_no_discount'] = item[13]
        order_dict['payment']['discount'] = item[14]
        order_dict['payment']['receivable'] = item[9]
        order_dict['payment']['payed_total'] = item[16]
        order_dict['payment']['small_change'] = item[15]
        order_dict['payment']['erase'] = item[17]
        order_dict['payment']['payment_scenarios'] = item[18]
        order_dict['payment']['payment_channel'] = item[19]
        order_dict['payment']['is_coupons'] = item[20]
        order_dict['payment']['pay_type'] = item[12]
        order_dict['payment']['money_before_whole_discount'] = item[13]
        order_dict['payment']['discount_type'] = item[11]
        order_dict['payment']['discount_rate'] = item[10]
        order_dict['pay_status'] = item[21]

        all_order_dict.update({item[0]: order_dict})

    details_clause = select([details]).where(details.c.create_date >= dt)
    rp = connection.execute(details_clause)
    details_results = rp.fetchall()
    for item in details_results:
        order_dict = all_order_dict.get(item[0])
        if order_dict:
            order_dict['operator_name'] = item[1]
            product = deepcopy(product_dict)
            product['code'] = item[3]
            product['count'] = item[4]
            product['price_per'] = item[5]
            product['name'] = item[6]
            product['retail_price'] = item[7]
            product['category'] = item[8]
            order_dict['product'].append(product)
            # all_order_dict.update({item[0]: order_dict})

    for key, item in all_order_dict.items():
        all_order_list.append(item)
    return all_order_list
