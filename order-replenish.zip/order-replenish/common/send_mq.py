import pika
import json
from config.config import config


def send2rabbitmq(order_data):
    user = config.get("rabbit", "USER")
    password = config.get("rabbit", "PASSWORD")
    topic = config.get("rabbit", "TOPIC")
    queue_name = config.get("rabbit", "QUEUE_NAME")
    host = config.get("rabbit", "HOST")
    port = config.getint("rabbit", "PORT")
    routing_key = config.get("rabbit", "ROUTING_KEY")

    try:
        credentials = pika.PlainCredentials(user, password)
        parameters = pika.ConnectionParameters(host, port, "/", credentials)
        connection = pika.BlockingConnection(parameters)
        channel = connection.channel()

        channel.exchange_declare(topic, exchange_type="topic", durable=True)
        channel.queue_declare(queue=queue_name, durable=True)

        channel.basic_publish(exchange=topic,
                              routing_key=routing_key,
                              body=json.dumps(order_data).encode('utf-8'),
                              properties=pika.BasicProperties(delivery_mode=2))
        connection.close()
        return True
    except Exception as err:
        return False
