# -*- coding: utf-8 -*-

import pymysql
from sqlalchemy import create_engine

from config.config import config

USERNAME = config.get('mysql', 'USERNAME')
PASSWORD = config.get('mysql', 'PASSWORD')
HOSTNAME = config.get('mysql', 'HOSTNAME')
DATABASE = config.get('mysql', 'DATABASE')
PORT = config.getint('mysql', 'PORT')


class MysqlClient(object):
    def __init__(self):
        sql_uri = "mysql+pymysql://{}:{}@{}:{}/{}?charset=utf8&autocommit=true"
        sql_uri = sql_uri.format(USERNAME, PASSWORD, HOSTNAME, PORT, DATABASE)
        self.engine = create_engine(
            sql_uri,
            echo=False,
            pool_size=50,
            pool_recycle=100)
        self.connection = self.engine.connect()

    def execute(self, clause):
        return self.connection.execute(clause)

