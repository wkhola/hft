#!/usr/bin/env python
# -*- coding: utf-8 -*-
from lib.oder_data_add import OderDataAdd
import pandas as pd

from util.logger import Logger

logger = Logger('migration.py')


def migrate():
    try:
        # connection = MysqlClient()
        # sql = """
        # select p.id, p.shop_id, p.order_id, p.product_id, s.name as product_name, p.quantity, p.create_date,
        # p.sale_price, p.return_price, p.operator
        # from shop_return_product as p
        # left join sys_shopdata as s on p.product_id = s.code and p.shop_id = s.shop_id where p.id > 18016
        # """
        # data = pd.read_sql(sql, connection.connection)
        # print(data)
        file_data = pd.read_csv('return_product.csv').fillna("")
        data = file_data
        grouped_data = data.groupby('order_id').apply(lambda  x : x.to_json(orient='records', date_format='iso'))
        for grouped in grouped_data.values:
            OderDataAdd.send_msg(grouped)
            logger.info(u"成功发送数据".format(grouped))


    except Exception as err:
        logger.error(err)
        raise

if __name__ == '__main__':
    logger.info(u"=====程序开始执行======")
    migrate()
    logger.info(u"=====程序执行结束======")
