#!/usr/bin/python
# coding:utf-8
from sqlalchemy import MetaData

metadata = MetaData()