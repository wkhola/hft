#!/usr/bin/python
# coding:utf-8
from source import metadata
from sqlalchemy import (Table, Column, Integer, String,
                        DateTime, Float)

details = Table('shop_sales_records', metadata,
                Column('order_id', Integer(), primary_key=True),
                Column('operator_name', String(25)),
                Column('create_date', DateTime()),
                Column('product_id', String(125)),
                Column('count', Integer()),
                Column('price_per', Float()),
                Column('name', String(25)),
                Column('retail_price', Float()),
                Column('category', Integer())
                )
