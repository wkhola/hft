#!/usr/bin/python
# coding:utf-8

from sqlalchemy import (Table, Column, Integer, String,
                        DateTime, Float)

from source import metadata

orders = Table('shop_order', metadata,
               Column('order_id', Integer(), primary_key=True),
               Column('create_date', DateTime()),
               Column('day_order_seq', Integer()),
               Column('origin', Integer()),
               Column('store_id', Integer()),
               Column('operator', String(125)),
               Column('member_id', Integer()),
               Column('face_id', String(125)),
               Column('product_count', Integer()),
               Column('receivable', Float()),
               Column('discount_rate', Float()),
               Column('discount_type', Integer()),
               Column('pay_type', String(25)),
               Column('total_no_discount', Float()),
               Column('discount', Float()),
               Column('small_change', Float()),
               Column('payed_total', Float()),
               Column('erase', Float()),
               Column('payment_scenarios', String(125)),
               Column('payment_channel', Integer()),
               Column('is_coupons', Integer()),
               Column('status', Integer())
               )

order_dict_ori = {
    # "is_computed": 1,
    "order_id": 0,
    "date": None,
    "origin": 0,
    "day_order_seq": 0,
    "store_id": 0,
    "operator": None,
    "member_id": "0",
    "face_id": "",
    "product_count": 0,
    "is_signed": 0,
    "operator_name": None,
    "pay_status": 0,
    "product": [],
    "payment": dict({
        "total_no_discount": 0,
        "discount": 0,
        "receivable": 0,
        "payed_total": 0,
        "small_change": 0,
        "erase": 0,
        "pay_type": "cash",
        "money_before_whole_discount": 0,
        "discount_type": 0,
        "discount_rate": 0,
        "payment_scenarios": "OTHER",
        "payment_channel": 0,
        "is_coupons": 0
    })
}

product_dict = dict({"code": None,
                     "count": None,
                     "price_per": 0,
                     "name": None,
                     "retail_price": 0,
                     "category": 0})
